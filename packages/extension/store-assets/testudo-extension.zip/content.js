function e(e){if(!e)throw Error(`[Testudo] Channel nonce is empty — aborting to prevent insecure channel`);let t=`testudo-req-${e}`,n=`testudo-res-${e}`;return{sendRequest(e){document.dispatchEvent(new CustomEvent(t,{detail:e,bubbles:!1,cancelable:!1}))},sendResponse(e){document.dispatchEvent(new CustomEvent(n,{detail:e,bubbles:!1,cancelable:!1}))},onRequest(e){let n=t=>e(t.detail);return document.addEventListener(t,n),()=>document.removeEventListener(t,n)},onResponse(e){let t=t=>e(t.detail);return document.addEventListener(n,t),()=>document.removeEventListener(n,t)}}}const t={ANALYZE_REQUEST:`TESTUDO_ANALYZE_REQUEST`,ANALYZE_RESULT:`TESTUDO_ANALYSIS_RESULT`,CHECK_ADDRESS:`TESTUDO_CHECK_ADDRESS`,ADDRESS_CHECK_RESULT:`TESTUDO_ADDRESS_CHECK_RESULT`,RESOLVE_TOKEN:`TESTUDO_RESOLVE_TOKEN`,TOKEN_RESULT:`TESTUDO_TOKEN_RESULT`,GET_SETTINGS:`TESTUDO_GET_SETTINGS`,SETTINGS_RESULT:`TESTUDO_SETTINGS_RESULT`,RECORD_BLOCKED:`TESTUDO_RECORD_BLOCKED`};window===window.top&&n();async function n(){let e=window.location.href;if(!(e.startsWith(`chrome-extension://`)||e.startsWith(`about:`)))try{let t=window.location.hostname.toLowerCase().replace(/^www\./,``),n=await chrome.runtime.sendMessage({type:`TESTUDO_CHECK_DOMAIN_BLOOM`,hostname:t});n?.inBloom&&r(t),chrome.runtime.sendMessage({type:`TESTUDO_CHECK_DOMAIN_API`,hostname:t,url:e})}catch{}}function r(e){let t=document.createElement(`div`);t.id=`testudo-phishing-block`,t.style.cssText=`
    position: fixed; inset: 0; z-index: 2147483647;
    background: #07070c; color: #f0f0f5;
    display: flex; align-items: center; justify-content: center;
    font-family: monospace; font-size: 16px;
  `,t.textContent=`[TESTUDO] Phishing domain blocked: ${e}. Verifying...`,document.documentElement.appendChild(t)}function i(){let e=document.createElement(`style`);e.id=`testudo-fonts`;let t=chrome.runtime.getURL(`fonts/`);e.textContent=`
@font-face {
  font-family: 'Material Symbols Outlined';
  font-style: normal;
  font-weight: 100 700;
  font-display: swap;
  src: url(${t}material-symbols-outlined.woff2) format('woff2');
}
@font-face {
  font-family: 'Geist';
  font-style: normal;
  font-weight: 300 700;
  font-display: swap;
  src: url(${t}geist-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@font-face {
  font-family: 'Geist';
  font-style: normal;
  font-weight: 300 700;
  font-display: swap;
  src: url(${t}geist-latin-ext.woff2) format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
@font-face {
  font-family: 'Geist Mono';
  font-style: normal;
  font-weight: 400 600;
  font-display: swap;
  src: url(${t}geist-mono-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@font-face {
  font-family: 'Geist Mono';
  font-style: normal;
  font-weight: 400 600;
  font-display: swap;
  src: url(${t}geist-mono-latin-ext.woff2) format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}`,(document.head||document.documentElement).appendChild(e)}function a(){let e=crypto.randomUUID(),t=!1;document.addEventListener(`testudo-handshake`,n=>{if(t)return;t=!0;let r=n.detail;document.dispatchEvent(new CustomEvent(`testudo-hs-${r}`,{detail:e,bubbles:!1,cancelable:!1}))},{once:!0});let n=document.createElement(`script`);return n.src=chrome.runtime.getURL(`injected.js`),n.type=`module`,(document.head||document.documentElement).appendChild(n),n.onload=()=>{n.remove()},e}i();const o=a();chrome.runtime.sendMessage({type:`HEARTBEAT`}).catch(()=>{});const s=[`app.uniswap.org`,`opensea.io`,`blur.io`,`lido.fi`,`curve.fi`,`app.1inch.io`,`pancakeswap.finance`,`app.aave.com`,`raydium.io`,`app.sushi.com`],c=2e4;if(s.some(e=>location.hostname===e||location.hostname.endsWith(`.${e}`))){let e=setInterval(()=>{chrome.runtime.sendMessage({type:`HEARTBEAT`}).catch(()=>clearInterval(e))},c)}function l(n){let r=e(n);function i(e,t,n){r.sendResponse({type:e,requestId:t,result:n})}r.onRequest(async e=>{let{requestId:n}=e;switch(e.type){case t.ANALYZE_REQUEST:{let r=e.delegateAddress,a=typeof e.chainId==`number`?e.chainId:void 0;if(!/^0x[a-fA-F0-9]{40}$/.test(r)){i(t.ANALYZE_RESULT,n,{risk:`UNKNOWN`,threats:[],address:r});return}try{let e=await chrome.runtime.sendMessage({type:`ANALYZE_DELEGATION`,delegateAddress:r,chainId:a});i(t.ANALYZE_RESULT,n,e)}catch(e){i(t.ANALYZE_RESULT,n,{risk:`UNKNOWN`,threats:[],address:r,error:String(e)})}break}case t.CHECK_ADDRESS:{let r=e.address,a=typeof e.chainId==`number`?e.chainId:void 0;if(!/^0x[a-fA-F0-9]{40}$/.test(r)){i(t.ADDRESS_CHECK_RESULT,n,{risk:`UNKNOWN`,threats:[],address:r,blocked:!1});return}try{let e=await chrome.runtime.sendMessage({type:`CHECK_ADDRESS`,address:r,chainId:a});i(t.ADDRESS_CHECK_RESULT,n,e)}catch{i(t.ADDRESS_CHECK_RESULT,n,{risk:`UNKNOWN`,threats:[],address:r,blocked:!1})}break}case t.RESOLVE_TOKEN:{let r=e.address,a={name:null,symbol:null,decimals:null};if(!/^0x[a-fA-F0-9]{40}$/.test(r)){i(t.TOKEN_RESULT,n,a);return}chrome.runtime.sendMessage({type:`RESOLVE_TOKEN`,address:r}).then(e=>i(t.TOKEN_RESULT,n,e??a)).catch(()=>i(t.TOKEN_RESULT,n,a));break}case t.GET_SETTINGS:chrome.runtime.sendMessage({type:`GET_SETTINGS`}).then(e=>i(t.SETTINGS_RESULT,n,e??{})).catch(()=>i(t.SETTINGS_RESULT,n,{}));break;case t.RECORD_BLOCKED:chrome.runtime.sendMessage({type:`RECORD_BLOCKED`}).catch(()=>{});break}})}l(o),chrome.runtime.onMessage.addListener((e,t,n)=>{e.type===`GET_PAGE_STATUS`&&n({active:!0,url:window.location.href})});