function e(){let e=document.createElement(`style`);e.id=`testudo-fonts`;let t=chrome.runtime.getURL(`fonts/`);e.textContent=`
@font-face {
  font-family: 'Material Symbols Outlined';
  font-style: normal;
  font-weight: 100 700;
  font-display: swap;
  src: url(${t}material-symbols-outlined.woff2) format('woff2');
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400 700;
  font-display: swap;
  src: url(${t}inter-latin-ext.woff2) format('woff2');
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
@font-face {
  font-family: 'Inter';
  font-style: normal;
  font-weight: 400 700;
  font-display: swap;
  src: url(${t}inter-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@font-face {
  font-family: 'Roboto Mono';
  font-style: normal;
  font-weight: 400 500;
  font-display: swap;
  src: url(${t}roboto-mono-latin.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}`,(document.head||document.documentElement).appendChild(e)}function t(){let e=document.createElement(`script`);e.src=chrome.runtime.getURL(`injected.js`),e.type=`module`,(document.head||document.documentElement).appendChild(e),e.onload=()=>{e.remove()}}e(),t(),window.addEventListener(`message`,async e=>{if(e.source===window){if(e.data?.type===`TESTUDO_ANALYZE_REQUEST`){let{requestId:t,delegateAddress:n}=e.data;console.log(`[Testudo Content] Received analysis request:`,n);try{let e=await chrome.runtime.sendMessage({type:`ANALYZE_DELEGATION`,delegateAddress:n});console.log(`[Testudo Content] Analysis result:`,e),window.postMessage({type:`TESTUDO_ANALYSIS_RESULT`,requestId:t,result:e},`*`)}catch(e){console.error(`[Testudo Content] Analysis error:`,e),window.postMessage({type:`TESTUDO_ANALYSIS_RESULT`,requestId:t,result:{risk:`UNKNOWN`,threats:[],address:n,error:String(e)}},`*`)}}if(e.data?.type===`TESTUDO_CHECK_ADDRESS`){let{requestId:t,address:n}=e.data;if(!/^0x[a-fA-F0-9]{40}$/.test(n)){window.postMessage({type:`TESTUDO_ADDRESS_CHECK_RESULT`,requestId:t,result:{risk:`UNKNOWN`,threats:[],address:n,blocked:!1}},`*`);return}try{let e=await chrome.runtime.sendMessage({type:`CHECK_ADDRESS`,address:n});window.postMessage({type:`TESTUDO_ADDRESS_CHECK_RESULT`,requestId:t,result:e},`*`)}catch(e){console.error(`[Testudo Content] Address check error:`,e),window.postMessage({type:`TESTUDO_ADDRESS_CHECK_RESULT`,requestId:t,result:{risk:`UNKNOWN`,threats:[],address:n,blocked:!1}},`*`)}}if(e.data?.type===`TESTUDO_RESOLVE_TOKEN`){let{requestId:t,address:n}=e.data,r={name:null,symbol:null,decimals:null};if(!/^0x[a-fA-F0-9]{40}$/.test(n)){window.postMessage({type:`TESTUDO_TOKEN_RESULT`,requestId:t,result:r},`*`);return}chrome.runtime.sendMessage({type:`RESOLVE_TOKEN`,address:n}).then(e=>{window.postMessage({type:`TESTUDO_TOKEN_RESULT`,requestId:t,result:e??r},`*`)}).catch(()=>{window.postMessage({type:`TESTUDO_TOKEN_RESULT`,requestId:t,result:r},`*`)})}if(e.data?.type===`TESTUDO_GET_SETTINGS`){let{requestId:t}=e.data;chrome.runtime.sendMessage({type:`GET_SETTINGS`}).then(e=>{window.postMessage({type:`TESTUDO_SETTINGS_RESULT`,requestId:t,result:e??{}},`*`)}).catch(()=>{window.postMessage({type:`TESTUDO_SETTINGS_RESULT`,requestId:t,result:{}},`*`)})}e.data?.type===`TESTUDO_RECORD_BLOCKED`&&(console.log(`[Testudo Content] Recording blocked delegation`),await chrome.runtime.sendMessage({type:`RECORD_BLOCKED`}))}}),chrome.runtime.onMessage.addListener((e,t,n)=>(e.type===`GET_PAGE_STATUS`&&n({active:!0,url:window.location.href}),!0)),console.log(`[Testudo Content] Content script loaded`);