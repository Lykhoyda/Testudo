async function e(){await t(),await n(),s()}async function t(){try{let e=await chrome.runtime.sendMessage({type:`GET_STATS`}),t=await chrome.storage.local.get([`blocked`,`scanned`]),n=t.blocked||0,r=t.scanned||e.cacheSize,i=document.getElementById(`stat-blocked`),a=document.getElementById(`stat-scanned`);i&&(i.textContent=String(n)),a&&(a.textContent=String(r))}catch(e){console.error(`[Testudo Popup] Error fetching stats:`,e)}}async function n(){try{let{scanHistory:e=[]}=await chrome.storage.local.get(`scanHistory`),t=document.getElementById(`recent-list`);if(!t)return;if(e.length===0){t.innerHTML=`<div class="empty-state">No recent scans</div>`;return}t.innerHTML=e.slice(0,5).map(e=>`
        <div class="activity-item">
          <div class="activity-icon-wrapper ${e.risk.toLowerCase()}">
            <span class="material-symbols-outlined activity-icon">${r(e.risk)}</span>
          </div>
          <div class="activity-content">
            <div class="activity-row">
              <span class="activity-badge ${e.risk.toLowerCase()}">${i(e.risk)}</span>
              <span class="activity-time">${a(e.timestamp)}</span>
            </div>
            <span class="activity-address">${o(e.address)}</span>
          </div>
        </div>
      `).join(``)}catch(e){console.error(`[Testudo Popup] Error loading recent scans:`,e)}}function r(e){let t={CRITICAL:`warning`,HIGH:`error`,MEDIUM:`info`,LOW:`check_circle`,UNKNOWN:`help`};return t[e]||`help`}function i(e){let t={CRITICAL:`Critical`,HIGH:`High`,MEDIUM:`Medium`,LOW:`Safe`,UNKNOWN:`Unknown`};return t[e]||e}function a(e){let t=Date.now(),n=t-e,r=Math.floor(n/6e4),i=Math.floor(n/36e5),a=Math.floor(n/864e5);return r<1?`just now`:r<60?`${r}m ago`:i<24?`${i}h ago`:a<7?`${a}d ago`:new Date(e).toLocaleDateString()}function o(e){return e.length<=16?e:`${e.slice(0,8)}...${e.slice(-6)}`}function s(){let e=document.getElementById(`settings-btn`);e&&e.addEventListener(`click`,()=>{chrome.runtime.openOptionsPage()});let t=document.getElementById(`view-all-btn`);t&&t.addEventListener(`click`,()=>{chrome.tabs.create({url:chrome.runtime.getURL(`options.html#history`)})});let n=document.getElementById(`notifications-btn`);n&&n.addEventListener(`click`,()=>{chrome.runtime.openOptionsPage()})}document.addEventListener(`DOMContentLoaded`,e);