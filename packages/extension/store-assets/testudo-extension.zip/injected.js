var e,t,n,r,i,a,o,s,c,l,u,d,f,p={},m=[],h=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,g=Array.isArray;function _(e,t){for(var n in t)e[n]=t[n];return e}function v(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function y(t,n,r){var i,a,o,s={};for(o in n)o==`key`?i=n[o]:o==`ref`?a=n[o]:s[o]=n[o];if(arguments.length>2&&(s.children=arguments.length>3?e.call(arguments,2):r),typeof t==`function`&&t.defaultProps!=null)for(o in t.defaultProps)s[o]===void 0&&(s[o]=t.defaultProps[o]);return b(t,s,i,a,null)}function b(e,r,i,a,o){var s={type:e,props:r,key:i,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++n,__i:-1,__u:0};return o==null&&t.vnode!=null&&t.vnode(s),s}function x(e){return e.children}function S(e,t){this.props=e,this.context=t}function C(e,t){if(t==null)return e.__?C(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type==`function`?C(e):null}function w(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return w(e)}}function T(e){(!e.__d&&(e.__d=!0)&&i.push(e)&&!E.__r++||a!=t.debounceRendering)&&((a=t.debounceRendering)||o)(E)}function E(){for(var e,n,r,a,o,c,l,u=1;i.length;)i.length>u&&i.sort(s),e=i.shift(),u=i.length,e.__d&&(r=void 0,a=void 0,o=(a=(n=e).__v).__e,c=[],l=[],n.__P&&((r=_({},a)).__v=a.__v+1,t.vnode&&t.vnode(r),M(n.__P,r,a,n.__n,n.__P.namespaceURI,32&a.__u?[o]:null,c,o??C(a),!!(32&a.__u),l),r.__v=a.__v,r.__.__k[r.__i]=r,re(c,r,l),a.__e=a.__=null,r.__e!=o&&w(r)));E.__r=0}function ee(e,t,n,r,i,a,o,s,c,l,u){var d,f,h,g,_,v,y,b=r&&r.__k||m,x=t.length;for(c=D(n,t,b,c,x),d=0;d<x;d++)(h=n.__k[d])!=null&&(f=h.__i==-1?p:b[h.__i]||p,h.__i=d,v=M(e,h,f,i,a,o,s,c,l,u),g=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&oe(f.ref,null,h),u.push(h.ref,h.__c||g,h)),_==null&&g!=null&&(_=g),(y=!!(4&h.__u))||f.__k===h.__k?c=O(h,c,e,y):typeof h.type==`function`&&v!==void 0?c=v:g&&(c=g.nextSibling),h.__u&=-7);return n.__e=_,c}function D(e,t,n,r,i){var a,o,s,c,l,u=n.length,d=u,f=0;for(e.__k=Array(i),a=0;a<i;a++)(o=t[a])!=null&&typeof o!=`boolean`&&typeof o!=`function`?(typeof o==`string`||typeof o==`number`||typeof o==`bigint`||o.constructor==String?o=e.__k[a]=b(null,o,null,null,null):g(o)?o=e.__k[a]=b(x,{children:o},null,null,null):o.constructor===void 0&&o.__b>0?o=e.__k[a]=b(o.type,o.props,o.key,o.ref?o.ref:null,o.__v):e.__k[a]=o,c=a+f,o.__=e,o.__b=e.__b+1,s=null,(l=o.__i=te(o,n,c,d))!=-1&&(d--,(s=n[l])&&(s.__u|=2)),s==null||s.__v==null?(l==-1&&(i>u?f--:i<u&&f++),typeof o.type!=`function`&&(o.__u|=4)):l!=c&&(l==c-1?f--:l==c+1?f++:(l>c?f--:f++,o.__u|=4))):e.__k[a]=null;if(d)for(a=0;a<u;a++)(s=n[a])!=null&&!(2&s.__u)&&(s.__e==r&&(r=C(s)),se(s,s));return r}function O(e,t,n,r){var i,a;if(typeof e.type==`function`){for(i=e.__k,a=0;i&&a<i.length;a++)i[a]&&(i[a].__=e,t=O(i[a],t,n,r));return t}e.__e!=t&&(r&&(t&&e.type&&!t.parentNode&&(t=C(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t&&=t.nextSibling;while(t!=null&&t.nodeType==8);return t}function te(e,t,n,r){var i,a,o,s=e.key,c=e.type,l=t[n],u=l!=null&&(2&l.__u)==0;if(l===null&&s==null||u&&s==l.key&&c==l.type)return n;if(r>(u?1:0)){for(i=n-1,a=n+1;i>=0||a<t.length;)if((l=t[o=i>=0?i--:a++])!=null&&!(2&l.__u)&&s==l.key&&c==l.type)return o}return-1}function k(e,t,n){t[0]==`-`?e.setProperty(t,n??``):e[t]=n==null?``:typeof n!=`number`||h.test(t)?n:n+`px`}function A(e,t,n,r,i){var a,o;n:if(t==`style`)if(typeof n==`string`)e.style.cssText=n;else{if(typeof r==`string`&&(e.style.cssText=r=``),r)for(t in r)n&&t in n||k(e.style,t,``);if(n)for(t in n)r&&n[t]==r[t]||k(e.style,t,n[t])}else if(t[0]==`o`&&t[1]==`n`)a=t!=(t=t.replace(c,`$1`)),o=t.toLowerCase(),t=o in e||t==`onFocusOut`||t==`onFocusIn`?o.slice(2):t.slice(2),e.l||={},e.l[t+a]=n,n?r?n.u=r.u:(n.u=l,e.addEventListener(t,a?d:u,a)):e.removeEventListener(t,a?d:u,a);else{if(i==`http://www.w3.org/2000/svg`)t=t.replace(/xlink(H|:h)/,`h`).replace(/sName$/,`s`);else if(t!=`width`&&t!=`height`&&t!=`href`&&t!=`list`&&t!=`form`&&t!=`tabIndex`&&t!=`download`&&t!=`rowSpan`&&t!=`colSpan`&&t!=`role`&&t!=`popover`&&t in e)try{e[t]=n??``;break n}catch{}typeof n==`function`||(n==null||!1===n&&t[4]!=`-`?e.removeAttribute(t):e.setAttribute(t,t==`popover`&&n==1?``:n))}}function j(e){return function(n){if(this.l){var r=this.l[n.type+e];if(n.t==null)n.t=l++;else if(n.t<r.u)return;return r(t.event?t.event(n):n)}}}function M(e,n,r,i,a,o,s,c,l,u){var d,f,p,m,h,y,b,C,w,T,E,D,O,te,k,A,j,M=n.type;if(n.constructor!==void 0)return null;128&r.__u&&(l=!!(32&r.__u),o=[c=n.__e=r.__e]),(d=t.__b)&&d(n);n:if(typeof M==`function`)try{if(C=n.props,w=`prototype`in M&&M.prototype.render,T=(d=M.contextType)&&i[d.__c],E=d?T?T.props.value:d.__:i,r.__c?b=(f=n.__c=r.__c).__=f.__E:(w?n.__c=f=new M(C,E):(n.__c=f=new S(C,E),f.constructor=M,f.render=ce),T&&T.sub(f),f.state||={},f.__n=i,p=f.__d=!0,f.__h=[],f._sb=[]),w&&f.__s==null&&(f.__s=f.state),w&&M.getDerivedStateFromProps!=null&&(f.__s==f.state&&(f.__s=_({},f.__s)),_(f.__s,M.getDerivedStateFromProps(C,f.__s))),m=f.props,h=f.state,f.__v=n,p)w&&M.getDerivedStateFromProps==null&&f.componentWillMount!=null&&f.componentWillMount(),w&&f.componentDidMount!=null&&f.__h.push(f.componentDidMount);else{if(w&&M.getDerivedStateFromProps==null&&C!==m&&f.componentWillReceiveProps!=null&&f.componentWillReceiveProps(C,E),n.__v==r.__v||!f.__e&&f.shouldComponentUpdate!=null&&!1===f.shouldComponentUpdate(C,f.__s,E)){for(n.__v!=r.__v&&(f.props=C,f.state=f.__s,f.__d=!1),n.__e=r.__e,n.__k=r.__k,n.__k.some(function(e){e&&(e.__=n)}),D=0;D<f._sb.length;D++)f.__h.push(f._sb[D]);f._sb=[],f.__h.length&&s.push(f);break n}f.componentWillUpdate!=null&&f.componentWillUpdate(C,f.__s,E),w&&f.componentDidUpdate!=null&&f.__h.push(function(){f.componentDidUpdate(m,h,y)})}if(f.context=E,f.props=C,f.__P=e,f.__e=!1,O=t.__r,te=0,w){for(f.state=f.__s,f.__d=!1,O&&O(n),d=f.render(f.props,f.state,f.context),k=0;k<f._sb.length;k++)f.__h.push(f._sb[k]);f._sb=[]}else do f.__d=!1,O&&O(n),d=f.render(f.props,f.state,f.context),f.state=f.__s;while(f.__d&&++te<25);f.state=f.__s,f.getChildContext!=null&&(i=_(_({},i),f.getChildContext())),w&&!p&&f.getSnapshotBeforeUpdate!=null&&(y=f.getSnapshotBeforeUpdate(m,h)),A=d,d!=null&&d.type===x&&d.key==null&&(A=ie(d.props.children)),c=ee(e,g(A)?A:[A],n,r,i,a,o,s,c,l,u),f.base=n.__e,n.__u&=-161,f.__h.length&&s.push(f),b&&(f.__E=f.__=null)}catch(e){if(n.__v=null,l||o!=null)if(e.then){for(n.__u|=l?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;o[o.indexOf(c)]=null,n.__e=c}else{for(j=o.length;j--;)v(o[j]);ne(n)}else n.__e=r.__e,n.__k=r.__k,e.then||ne(n);t.__e(e,n,r)}else o==null&&n.__v==r.__v?(n.__k=r.__k,n.__e=r.__e):c=n.__e=ae(r.__e,n,r,i,a,o,s,l,u);return(d=t.diffed)&&d(n),128&n.__u?void 0:c}function ne(e){e&&e.__c&&(e.__c.__e=!0),e&&e.__k&&e.__k.forEach(ne)}function re(e,n,r){for(var i=0;i<r.length;i++)oe(r[i],r[++i],r[++i]);t.__c&&t.__c(n,e),e.some(function(n){try{e=n.__h,n.__h=[],e.some(function(e){e.call(n)})}catch(e){t.__e(e,n.__v)}})}function ie(e){return typeof e!=`object`||!e||e.__b&&e.__b>0?e:g(e)?e.map(ie):_({},e)}function ae(n,r,i,a,o,s,c,l,u){var d,f,m,h,_,y,b,x=i.props||p,S=r.props,w=r.type;if(w==`svg`?o=`http://www.w3.org/2000/svg`:w==`math`?o=`http://www.w3.org/1998/Math/MathML`:o||=`http://www.w3.org/1999/xhtml`,s!=null){for(d=0;d<s.length;d++)if((_=s[d])&&`setAttribute`in _==!!w&&(w?_.localName==w:_.nodeType==3)){n=_,s[d]=null;break}}if(n==null){if(w==null)return document.createTextNode(S);n=document.createElementNS(o,w,S.is&&S),l&&(t.__m&&t.__m(r,s),l=!1),s=null}if(w==null)x===S||l&&n.data==S||(n.data=S);else{if(s&&=e.call(n.childNodes),!l&&s!=null)for(x={},d=0;d<n.attributes.length;d++)x[(_=n.attributes[d]).name]=_.value;for(d in x)if(_=x[d],d!=`children`){if(d==`dangerouslySetInnerHTML`)m=_;else if(!(d in S)){if(d==`value`&&`defaultValue`in S||d==`checked`&&`defaultChecked`in S)continue;A(n,d,null,_,o)}}for(d in S)_=S[d],d==`children`?h=_:d==`dangerouslySetInnerHTML`?f=_:d==`value`?y=_:d==`checked`?b=_:l&&typeof _!=`function`||x[d]===_||A(n,d,_,x[d],o);if(f)l||m&&(f.__html==m.__html||f.__html==n.innerHTML)||(n.innerHTML=f.__html),r.__k=[];else if(m&&(n.innerHTML=``),ee(r.type==`template`?n.content:n,g(h)?h:[h],r,i,a,w==`foreignObject`?`http://www.w3.org/1999/xhtml`:o,s,c,s?s[0]:i.__k&&C(i,0),l,u),s!=null)for(d=s.length;d--;)v(s[d]);l||(d=`value`,w==`progress`&&y==null?n.removeAttribute(`value`):y!=null&&(y!==n[d]||w==`progress`&&!y||w==`option`&&y!=x[d])&&A(n,d,y,x[d],o),d=`checked`,b!=null&&b!=n[d]&&A(n,d,b,x[d],o))}return n}function oe(e,n,r){try{if(typeof e==`function`){var i=typeof e.__u==`function`;i&&e.__u(),i&&n==null||(e.__u=e(n))}else e.current=n}catch(e){t.__e(e,r)}}function se(e,n,r){var i,a;if(t.unmount&&t.unmount(e),(i=e.ref)&&(i.current&&i.current!=e.__e||oe(i,null,n)),(i=e.__c)!=null){if(i.componentWillUnmount)try{i.componentWillUnmount()}catch(e){t.__e(e,n)}i.base=i.__P=null}if(i=e.__k)for(a=0;a<i.length;a++)i[a]&&se(i[a],n,r||typeof e.type!=`function`);r||v(e.__e),e.__c=e.__=e.__e=void 0}function ce(e,t,n){return this.constructor(e,n)}function le(n,r,i){var a,o,s,c;r==document&&(r=document.documentElement),t.__&&t.__(n,r),o=(a=typeof i==`function`)?null:i&&i.__k||r.__k,s=[],c=[],M(r,n=(!a&&i||r).__k=y(x,null,[n]),o||p,p,r.namespaceURI,!a&&i?[i]:o?null:r.firstChild?e.call(r.childNodes):null,s,!a&&i?i:o?o.__e:r.firstChild,a,c),re(s,n,c)}e=m.slice,t={__e:function(e,t,n,r){for(var i,a,o;t=t.__;)if((i=t.__c)&&!i.__)try{if((a=i.constructor)&&a.getDerivedStateFromError!=null&&(i.setState(a.getDerivedStateFromError(e)),o=i.__d),i.componentDidCatch!=null&&(i.componentDidCatch(e,r||{}),o=i.__d),o)return i.__E=i}catch(t){e=t}throw e}},n=0,r=function(e){return e!=null&&e.constructor===void 0},S.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=_({},this.state),typeof e==`function`&&(e=e(_({},n),this.props)),e&&_(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),T(this))},S.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),T(this))},S.prototype.render=x,i=[],o=typeof Promise==`function`?Promise.prototype.then.bind(Promise.resolve()):setTimeout,s=function(e,t){return e.__v.__b-t.__v.__b},E.__r=0,c=/(PointerCapture)$|Capture$/i,l=0,u=j(!1),d=j(!0),f=0;var ue,N,de,fe,pe=0,me=[],P=t,he=P.__b,ge=P.__r,_e=P.diffed,ve=P.__c,ye=P.unmount,be=P.__;function xe(e,t){P.__h&&P.__h(N,e,pe||t),pe=0;var n=N.__H||={__:[],__h:[]};return e>=n.__.length&&n.__.push({}),n.__[e]}function Se(e,t){var n=xe(ue++,3);!P.__s&&ke(n.__H,t)&&(n.__=e,n.u=t,N.__H.__h.push(n))}function Ce(e,t){var n=xe(ue++,7);return ke(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function we(){for(var e;e=me.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(De),e.__H.__h.forEach(Oe),e.__H.__h=[]}catch(t){e.__H.__h=[],P.__e(t,e.__v)}}P.__b=function(e){N=null,he&&he(e)},P.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),be&&be(e,t)},P.__r=function(e){ge&&ge(e),ue=0;var t=(N=e.__c).__H;t&&(de===N?(t.__h=[],N.__h=[],t.__.forEach(function(e){e.__N&&(e.__=e.__N),e.u=e.__N=void 0})):(t.__h.forEach(De),t.__h.forEach(Oe),t.__h=[],ue=0)),de=N},P.diffed=function(e){_e&&_e(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(me.push(t)!==1&&fe===P.requestAnimationFrame||((fe=P.requestAnimationFrame)||Ee)(we)),t.__H.__.forEach(function(e){e.u&&(e.__H=e.u),e.u=void 0})),de=N=null},P.__c=function(e,t){t.some(function(e){try{e.__h.forEach(De),e.__h=e.__h.filter(function(e){return!e.__||Oe(e)})}catch(n){t.some(function(e){e.__h&&=[]}),t=[],P.__e(n,e.__v)}}),ve&&ve(e,t)},P.unmount=function(e){ye&&ye(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(e){try{De(e)}catch(e){t=e}}),n.__H=void 0,t&&P.__e(t,n.__v))};var Te=typeof requestAnimationFrame==`function`;function Ee(e){var t,n=function(){clearTimeout(r),Te&&cancelAnimationFrame(t),setTimeout(e)},r=setTimeout(n,35);Te&&(t=requestAnimationFrame(n))}function De(e){var t=N,n=e.__c;typeof n==`function`&&(e.__c=void 0,n()),N=t}function Oe(e){var t=N;e.__c=e.__(),N=t}function ke(e,t){return!e||e.length!==t.length||t.some(function(t,n){return t!==e[n]})}var Ae=Symbol.for(`preact-signals`);function je(){if(L>1)L--;else{for(var e,t=!1;I!==void 0;){var n=I;for(I=void 0,Fe++;n!==void 0;){var r=n.o;if(n.o=void 0,n.f&=-3,!(8&n.f)&&Re(n))try{n.c()}catch(n){t||(e=n,t=!0)}n=r}}if(Fe=0,L--,t)throw e}}function Me(e){if(L>0)return e();L++;try{return e()}finally{je()}}var F=void 0;function Ne(e){var t=F;F=void 0;try{return e()}finally{F=t}}var Pe,I=void 0,L=0,Fe=0,Ie=0;function Le(e){if(F!==void 0){var t=e.n;if(t===void 0||t.t!==F)return t={i:0,S:e,p:F.s,n:void 0,t:F,e:void 0,x:void 0,r:t},F.s!==void 0&&(F.s.n=t),F.s=t,e.n=t,32&F.f&&e.S(t),t;if(t.i===-1)return t.i=0,t.n!==void 0&&(t.n.p=t.p,t.p!==void 0&&(t.p.n=t.n),t.p=F.s,t.n=void 0,F.s.n=t,F.s=t),t}}function R(e,t){this.v=e,this.i=0,this.n=void 0,this.t=void 0,this.W=t?.watched,this.Z=t?.unwatched,this.name=t?.name}R.prototype.brand=Ae,R.prototype.h=function(){return!0},R.prototype.S=function(e){var t=this,n=this.t;n!==e&&e.e===void 0&&(e.x=n,this.t=e,n===void 0?Ne(function(){var e;(e=t.W)==null||e.call(t)}):n.e=e)},R.prototype.U=function(e){var t=this;if(this.t!==void 0){var n=e.e,r=e.x;n!==void 0&&(n.x=r,e.e=void 0),r!==void 0&&(r.e=n,e.x=void 0),e===this.t&&(this.t=r,r===void 0&&Ne(function(){var e;(e=t.Z)==null||e.call(t)}))}},R.prototype.subscribe=function(e){var t=this;return Ge(function(){var n=t.value,r=F;F=void 0;try{e(n)}finally{F=r}},{name:`sub`})},R.prototype.valueOf=function(){return this.value},R.prototype.toString=function(){return this.value+``},R.prototype.toJSON=function(){return this.value},R.prototype.peek=function(){var e=F;F=void 0;try{return this.value}finally{F=e}},Object.defineProperty(R.prototype,`value`,{get:function(){var e=Le(this);return e!==void 0&&(e.i=this.i),this.v},set:function(e){if(e!==this.v){if(Fe>100)throw Error(`Cycle detected`);this.v=e,this.i++,Ie++,L++;try{for(var t=this.t;t!==void 0;t=t.x)t.t.N()}finally{je()}}}});function z(e,t){return new R(e,t)}function Re(e){for(var t=e.s;t!==void 0;t=t.n)if(t.S.i!==t.i||!t.S.h()||t.S.i!==t.i)return!0;return!1}function ze(e){for(var t=e.s;t!==void 0;t=t.n){var n=t.S.n;if(n!==void 0&&(t.r=n),t.S.n=t,t.i=-1,t.n===void 0){e.s=t;break}}}function Be(e){for(var t=e.s,n=void 0;t!==void 0;){var r=t.p;t.i===-1?(t.S.U(t),r!==void 0&&(r.n=t.n),t.n!==void 0&&(t.n.p=r)):n=t,t.S.n=t.r,t.r!==void 0&&(t.r=void 0),t=r}e.s=n}function B(e,t){R.call(this,void 0),this.x=e,this.s=void 0,this.g=Ie-1,this.f=4,this.W=t?.watched,this.Z=t?.unwatched,this.name=t?.name}B.prototype=new R,B.prototype.h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===Ie))return!0;if(this.g=Ie,this.f|=1,this.i>0&&!Re(this))return this.f&=-2,!0;var e=F;try{ze(this),F=this;var t=this.x();(16&this.f||this.v!==t||this.i===0)&&(this.v=t,this.f&=-17,this.i++)}catch(e){this.v=e,this.f|=16,this.i++}return F=e,Be(this),this.f&=-2,!0},B.prototype.S=function(e){if(this.t===void 0){this.f|=36;for(var t=this.s;t!==void 0;t=t.n)t.S.S(t)}R.prototype.S.call(this,e)},B.prototype.U=function(e){if(this.t!==void 0&&(R.prototype.U.call(this,e),this.t===void 0)){this.f&=-33;for(var t=this.s;t!==void 0;t=t.n)t.S.U(t)}},B.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var e=this.t;e!==void 0;e=e.x)e.t.N()}},Object.defineProperty(B.prototype,`value`,{get:function(){if(1&this.f)throw Error(`Cycle detected`);var e=Le(this);if(this.h(),e!==void 0&&(e.i=this.i),16&this.f)throw this.v;return this.v}});function Ve(e,t){return new B(e,t)}function He(e){var t=e.u;if(e.u=void 0,typeof t==`function`){L++;var n=F;F=void 0;try{t()}catch(t){throw e.f&=-2,e.f|=8,Ue(e),t}finally{F=n,je()}}}function Ue(e){for(var t=e.s;t!==void 0;t=t.n)t.S.U(t);e.x=void 0,e.s=void 0,He(e)}function We(e){if(F!==this)throw Error(`Out-of-order effect`);Be(this),F=e,this.f&=-2,8&this.f&&Ue(this),je()}function V(e,t){this.x=e,this.u=void 0,this.s=void 0,this.o=void 0,this.f=32,this.name=t?.name,Pe&&Pe.push(this)}V.prototype.c=function(){var e=this.S();try{if(8&this.f||this.x===void 0)return;var t=this.x();typeof t==`function`&&(this.u=t)}finally{e()}},V.prototype.S=function(){if(1&this.f)throw Error(`Cycle detected`);this.f|=1,this.f&=-9,He(this),ze(this),L++;var e=F;return F=this,We.bind(this,e)},V.prototype.N=function(){2&this.f||(this.f|=2,this.o=I,I=this)},V.prototype.d=function(){this.f|=8,1&this.f||Ue(this)},V.prototype.dispose=function(){this.d()};function Ge(e,t){var n=new V(e,t);try{n.c()}catch(e){throw n.d(),e}var r=n.d.bind(n);return r[Symbol.dispose]=r,r}var Ke,qe,Je,Ye=typeof window<`u`&&!!window.__PREACT_SIGNALS_DEVTOOLS__,Xe=[],Ze=[];Ge(function(){Ke=this.N})();function H(e,n){t[e]=n.bind(null,t[e]||function(){})}function Qe(e){Je&&Je(),Je=e&&e.S()}function $e(e){var t=this,n=e.data,i=tt(n);i.value=n;var a=Ce(function(){for(var e=t,n=t.__v;n=n.__;)if(n.__c){n.__c.__$f|=4;break}var a=Ve(function(){var e=i.value.value;return e===0?0:!0===e?``:e||``}),o=Ve(function(){return!Array.isArray(a.value)&&!r(a.value)}),s=Ge(function(){if(this.N=at,o.value){var t=a.value;e.__v&&e.__v.__e&&e.__v.__e.nodeType===3&&(e.__v.__e.data=t)}}),c=t.__$u.d;return t.__$u.d=function(){s(),c.call(this)},[o,a]},[]),o=a[0],s=a[1];return o.value?s.peek():s.value}$e.displayName=`ReactiveTextNode`,Object.defineProperties(R.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:$e},props:{configurable:!0,get:function(){return{data:this}}},__b:{configurable:!0,value:1}}),H(`__b`,function(e,t){if(typeof t.type==`string`){var n,r=t.props;for(var i in r)if(i!==`children`){var a=r[i];a instanceof R&&(n||(t.__np=n={}),n[i]=a,r[i]=a.peek())}}e(t)}),H(`__r`,function(e,t){if(t.type!==x){Qe();var n,r=t.__c;r&&(r.__$f&=-2,(n=r.__$u)===void 0&&(r.__$u=n=function(e,t){var n;return Ge(function(){n=this},{name:t}),n.c=e,n}(function(){var e;Ye&&((e=n.y)==null||e.call(n)),r.__$f|=1,r.setState({})},typeof t.type==`function`?t.type.displayName||t.type.name:``))),qe=r,Qe(n)}e(t)}),H(`__e`,function(e,t,n,r){Qe(),qe=void 0,e(t,n,r)}),H(`diffed`,function(e,t){Qe(),qe=void 0;var n;if(typeof t.type==`string`&&(n=t.__e)){var r=t.__np,i=t.props;if(r){var a=n.U;if(a)for(var o in a){var s=a[o];s!==void 0&&!(o in r)&&(s.d(),a[o]=void 0)}else a={},n.U=a;for(var c in r){var l=a[c],u=r[c];l===void 0?(l=et(n,c,u,i),a[c]=l):l.o(u,i)}}}e(t)});function et(e,t,n,r){var i=t in e&&e.ownerSVGElement===void 0,a=z(n);return{o:function(e,t){a.value=e,r=t},d:Ge(function(){this.N=at;var n=a.value.value;r[t]!==n&&(r[t]=n,i?e[t]=n:n!=null&&(!1!==n||t[4]===`-`)?e.setAttribute(t,n):e.removeAttribute(t))})}}H(`unmount`,function(e,t){if(typeof t.type==`string`){var n=t.__e;if(n){var r=n.U;if(r)for(var i in n.U=void 0,r){var a=r[i];a&&a.d()}}}else{var o=t.__c;if(o){var s=o.__$u;s&&(o.__$u=void 0,s.d())}}e(t)}),H(`__h`,function(e,t,n,r){(r<3||r===9)&&(t.__$f|=2),e(t,n,r)}),S.prototype.shouldComponentUpdate=function(e,t){if(this.__R)return!0;var n=this.__$u,r=n&&n.s!==void 0;for(var i in t)return!0;if(this.__f||typeof this.u==`boolean`&&!0===this.u){var a=2&this.__$f;if(!(r||a||4&this.__$f)||1&this.__$f)return!0}else if(!(r||4&this.__$f)||3&this.__$f)return!0;for(var o in e)if(o!==`__source`&&e[o]!==this.props[o])return!0;for(var s in this.props)if(!(s in e))return!0;return!1};function tt(e,t){return Ce(function(){return z(e,t)},[])}var nt=typeof requestAnimationFrame>`u`?setTimeout:function(e){var t=function(){clearTimeout(n),cancelAnimationFrame(r),e()},n=setTimeout(t,35),r=requestAnimationFrame(t)},rt=function(e){queueMicrotask(function(){queueMicrotask(e)})};function it(){Me(function(){for(var e;e=Ze.shift();)Ke.call(e)})}function at(){Ze.push(this)===1&&(t.requestAnimationFrame||rt)(it)}const ot={visible:!1,analysis:null,context:`delegation`,resolver:null},U=z(ot),st=z(``),ct=Ve(()=>st.value.trim().toUpperCase()===`I ACCEPT THE RISK`),lt=z(`content_copy`);function ut(e){let t=U.value.resolver;return t&&t(!1),new Promise(t=>{st.value=``,lt.value=`content_copy`,U.value={visible:!0,analysis:e.analysis,context:e.context??`delegation`,permitInfo:e.permitInfo,approvalInfo:e.approvalInfo,nftApprovalInfo:e.nftApprovalInfo,blindSignatureInfo:e.blindSignatureInfo,typedDataScanInfo:e.typedDataScanInfo,intent:e.intent,resolver:t}})}function dt(e){let{resolver:t}=U.value;U.value=ot,st.value=``,t&&t(e)}function ft(){window.postMessage({type:`TESTUDO_RECORD_BLOCKED`},`*`),dt(!1)}function pt(){dt(!0)}function mt(e){let t=U.value.analysis;t&&e(t.address,`Trusted from warning`).then(e=>{e&&dt(!0)})}function ht(){ct.value&&dt(!0)}async function gt(){let e=U.value.analysis?.address;if(e)try{await navigator.clipboard.writeText(e),lt.value=`check`,setTimeout(()=>{lt.value=`content_copy`},2e3)}catch{console.error(`[Testudo] Failed to copy address`)}}const W=z({visible:!1,title:``,text:``});let _t;function vt(e){let t=e.warnings?.find(e=>e.severity!==`INFO`);W.value={visible:!0,title:t?.title||`Review Required`,text:t?.description||`Review this delegation carefully`},_t&&clearTimeout(_t),_t=setTimeout(()=>{W.value={...W.value,visible:!1}},7e3)}function yt(){_t&&clearTimeout(_t),W.value={...W.value,visible:!1}}const G=z({visible:!1,address:``});let bt;function xt(e){G.value={visible:!0,address:e.address},bt&&clearTimeout(bt),bt=setTimeout(()=>{G.value={...G.value,visible:!1}},5e3)}function St(){bt&&clearTimeout(bt),G.value={...G.value,visible:!1}}var Ct=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,wt=0,Tt=Array.isArray;function K(e,n,r,i,a,o){n||={};var s,c,l=n;if(`ref`in l)for(c in l={},n)c==`ref`?s=n[c]:l[c]=n[c];var u={type:e,props:l,key:r,ref:s,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--wt,__i:-1,__u:0,__source:a,__self:o};if(typeof e==`function`&&(s=e.defaultProps))for(c in s)l[c]===void 0&&(l[c]=s[c]);return t.vnode&&t.vnode(u),u}function Et(){let{visible:e,title:t,text:n}=W.value;return e?K(`div`,{class:`testudo-toast`,id:`testudo-info-toast`,children:[K(`span`,{class:`testudo-toast-icon`,children:`info`}),K(`div`,{class:`testudo-toast-content`,children:[K(`div`,{class:`testudo-toast-title`,children:[K(`span`,{class:`testudo-toast-icon-inline`,children:`bolt`}),t]}),K(`div`,{class:`testudo-toast-text`,children:n}),K(`button`,{type:`button`,class:`testudo-toast-dismiss`,id:`testudo-toast-dismiss`,onClick:yt,children:`Dismiss`})]})]}):null}function q(e,t=10,n=6){return e.length<=t+n?e:`${e.slice(0,t)}...${e.slice(-n)}`}function Dt(){let{visible:e,address:t}=G.value;return e?K(`div`,{class:`testudo-toast-unknown`,id:`testudo-unknown-toast`,children:[K(`span`,{class:`testudo-toast-unknown-icon`,children:`help_outline`}),K(`div`,{class:`testudo-toast-unknown-content`,children:[K(`div`,{class:`testudo-toast-unknown-title`,children:`Unverified Contract`}),K(`div`,{class:`testudo-toast-unknown-text`,children:`This contract has no bytecode or doesn't exist on-chain. It may be an EOA (regular wallet) or undeployed contract.`}),K(`div`,{class:`testudo-toast-unknown-address`,children:q(t)}),K(`button`,{type:`button`,class:`testudo-toast-unknown-dismiss`,id:`testudo-unknown-dismiss`,onClick:St,children:`Dismiss`})]})]}):null}function Ot(e,t,n,r=1e4){return new Promise((i,a)=>{let o=Math.random().toString(36).substring(7),s=e=>{e.data?.type===t&&e.data?.requestId===o&&(window.removeEventListener(`message`,s),i(e.data.result))};window.addEventListener(`message`,s),window.postMessage({type:e,requestId:o,...n},`*`),setTimeout(()=>{window.removeEventListener(`message`,s),a(Error(`${e} timeout`))},r)})}function kt(e){return Ot(`TESTUDO_CHECK_ADDRESS`,`TESTUDO_ADDRESS_CHECK_RESULT`,{address:e})}async function At(e){let t=new Map;for(let n of e){let e=n.address.toLowerCase();t.has(e)||t.set(e,[]),t.get(e)?.push(n)}let n=new Map,r=[],i=Array.from(t.entries()).map(async([e,t])=>{try{let i=await kt(e);n.set(e,i),(i.risk===`CRITICAL`||i.risk===`HIGH`)&&r.push(...t)}catch{}});return await Promise.all(i),{malicious:r,results:n}}function jt(e){return Ot(`TESTUDO_ANALYZE_REQUEST`,`TESTUDO_ANALYSIS_RESULT`,{delegateAddress:e})}function Mt(e){return Ot(`TESTUDO_RESOLVE_TOKEN`,`TESTUDO_TOKEN_RESULT`,{address:e},3e3).catch(()=>({name:null,symbol:null,decimals:null}))}function Nt(e,t){return new Promise(n=>{let r=Math.random().toString(36).substring(7),i=e=>{e.data?.type===`TESTUDO_WHITELIST_RESULT`&&e.data?.requestId===r&&(window.removeEventListener(`message`,i),n(e.data.success))};window.addEventListener(`message`,i),window.postMessage({type:`TESTUDO_WHITELIST_REQUEST`,requestId:r,address:e,label:t},`*`),setTimeout(()=>{window.removeEventListener(`message`,i),n(!1)},5e3)})}function Pt(e){switch(e){case`eth-sign-danger`:case`blind-signature`:return`Signer Address`;case`typed-data-scan`:return`Malicious Address`;case`nft-approval`:return`Operator Address`;case`approval`:case`permit`:return`Spender Address`;case`transaction`:return`Recipient Address`;default:return`Target Contract`}}function Ft({address:e,context:t,copyIcon:n,onCopy:r}){return K(`div`,{class:`testudo-address-section`,children:K(`div`,{class:`testudo-address-box`,children:[K(`span`,{class:`testudo-address-label`,children:Pt(t)}),K(`div`,{class:`testudo-address-value`,children:[K(`span`,{class:`testudo-address-text`,children:q(e)}),K(`button`,{type:`button`,class:`testudo-copy-btn`,id:`testudo-copy`,title:`Copy Address`,onClick:r,children:K(`span`,{class:`testudo-material-icon`,children:n})})]})]})})}function It({analysis:e}){let t=e.warnings?.find(e=>e.severity===`CRITICAL`||e.severity===`HIGH`)||e.warnings?.find(e=>e.severity===`MEDIUM`),n=e.risk===`CRITICAL`?`Fund Drain Detected`:`Multiple Risk Factors Detected`,r=e.risk===`CRITICAL`?`This contract contains logic known to drain wallets immediately upon signature.`:`This contract has multiple concerning patterns that warrant caution.`,i=t?.title||n,a=t?.description||r,o=e.risk===`MEDIUM`;return K(`div`,{class:`testudo-alert${o?` testudo-alert-medium`:``}`,children:[K(`div`,{class:`testudo-alert-header`,children:[K(`span`,{class:`testudo-material-icon`,children:o?`info`:`error`}),K(`span`,{class:`testudo-alert-title`,children:[e.risk,`: `,i]})]}),K(`p`,{class:`testudo-alert-description`,children:a})]})}const Lt={approve:`0x095ea7b3`,increaseAllowance:`0x39509351`,decreaseAllowance:`0xa457c2d7`},Rt={setApprovalForAll:`0xa22cb465`},zt={"0x1e0049783f008a0085193e00003d00cd54003c71":`OpenSea Seaport 1.1`,"0x00000000000001ad428e4906ae43d8f9852d0dd6":`OpenSea Seaport 1.4`,"0x00000000000000adc04c56bf30ac9d3c0aaf14dc":`OpenSea Seaport 1.5`,"0x00000000000000adc04c56bf30ac9d3c0aaf14dd":`OpenSea Seaport 1.6`,"0x000000000000ad05ccc4f10045630fb830b95127":`Blur`,"0x59728544b08ab483533076417fbbb2fd0b17ce3a":`LooksRare Exchange`,"0x74312363e45dcaba76c59ec49a7aa8a65a67eed3":`X2Y2 Exchange`,"0x2b2e8cda09bba9660dca5cb6233787738ad68329":`Sudoswap`},Bt=`0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff`,Vt=`0xffffffffffffffffffffffffffffffffffffffff`;function Ht(e){if(!e||e.length<10)return!1;let t=e.slice(0,10).toLowerCase();return Object.values(Lt).includes(t)}function Ut(e,t){let n=e.slice(0,10).toLowerCase();if(e.length<138)return null;let r=e.slice(10,74),i=e.slice(74,138),a=`0x${r.slice(24).toLowerCase()}`;if(!/^0x[a-fA-F0-9]{40}$/.test(a))return null;let o=n===Lt.approve?`approve`:n===Lt.increaseAllowance?`increaseAllowance`:`decreaseAllowance`;return{type:o,spender:a,amount:`0x${i}`,tokenAddress:t.toLowerCase()}}function J(e){if(!e)return!1;let t=e.toLowerCase();if(t===Bt||t===Vt||t===`unlimited`)return!0;if(/[eE]/.test(e)){let t=Number(e);if(!Number.isNaN(t)&&t>1e30)return!0}try{return BigInt(e)>BigInt(10)**BigInt(30)}catch{return!1}}function Wt(e){if(J(e))return`UNLIMITED`;try{let t=BigInt(e);return t.toLocaleString()}catch{return`Invalid Amount Data`}}function Gt(e){try{return BigInt(e)===BigInt(0)}catch{return!1}}function Kt(e){if(!e||e.length<10)return!1;let t=e.slice(0,10).toLowerCase();return t===Rt.setApprovalForAll}function qt(e,t){if(e.length<138)return null;let n=e.slice(10,74),r=e.slice(74,138),i=`0x${n.slice(24).toLowerCase()}`;if(!/^0x[a-fA-F0-9]{40}$/.test(i))return null;let a=BigInt(`0x${r}`)!==BigInt(0);return{type:`setApprovalForAll`,operator:i,approved:a,collectionAddress:t.toLowerCase()}}function Jt(e){return zt[e.toLowerCase()]||null}function Y({label:e,value:t,style:n,mb:r=!0}){return K(`div`,{class:`testudo-address-box`,style:r?`margin-bottom:6px`:void 0,children:[K(`span`,{class:`testudo-address-label`,children:e}),K(`span`,{class:`testudo-address-text`,style:n,children:t})]})}function Yt(e){switch(e){case`danger`:return`color:#e74c3c;font-weight:700`;case`warning`:return`color:#f59e0b;font-weight:600`;default:return}}function Xt({intent:e}){return K(`div`,{class:`testudo-address-section`,children:[K(`div`,{class:`testudo-intent-action`,children:e.action}),e.details.map((t,n)=>K(Y,{label:t.label,value:t.value,style:t.mono?`font-family:monospace;font-size:12px;${Yt(t.emphasis)??``}`:Yt(t.emphasis),mb:n<e.details.length-1},t.label)),e.chainName&&K(Y,{label:`Network`,value:e.chainName,mb:!1})]})}function Zt({permitInfo:e,approvalInfo:t,nftApprovalInfo:n,blindSignatureInfo:r,typedDataScanInfo:i,intent:a}){return a?K(Xt,{intent:a}):K(x,{children:[e&&K(`div`,{class:`testudo-address-section`,children:[e.tokenName&&K(Y,{label:`Token`,value:`${e.tokenName}${e.token?` (${e.token.slice(0,8)}...)`:``}`}),K(Y,{label:`Amount`,value:J(e.value)?`UNLIMITED`:e.value===`batch`?`Batch (multiple tokens)`:e.value||`Unknown`,style:J(e.value)?`color:#e74c3c;font-weight:700`:void 0}),e.deadline&&K(Y,{label:`Deadline`,value:String(e.deadline),mb:!1})]}),t&&K(`div`,{class:`testudo-address-section`,children:[K(Y,{label:`Token Contract`,value:q(t.tokenAddress)}),K(Y,{label:`Amount`,value:Wt(t.amount),style:J(t.amount)?`color:#e74c3c;font-weight:700`:void 0}),K(Y,{label:`Operation`,value:t.type===`approve`?`approve()`:t.type===`increaseAllowance`?`increaseAllowance()`:`decreaseAllowance()`,mb:!1})]}),n&&K(`div`,{class:`testudo-address-section`,children:[K(Y,{label:`Collection`,value:q(n.collectionAddress)}),K(Y,{label:`Access Level`,value:`FULL COLLECTION`,style:`color:#e74c3c;font-weight:700`,mb:!1})]}),r&&K(`div`,{class:`testudo-address-section`,children:[K(Y,{label:`Method`,value:r.type}),K(Y,{label:`Message${r.isHex?` (hex)`:``}`,value:r.messagePreview,style:`font-family:monospace;font-size:12px;word-break:break-all`,mb:!1})]}),i&&K(`div`,{class:`testudo-address-section`,children:[K(Y,{label:`Primary Type`,value:i.primaryType}),i.domainName&&K(Y,{label:`Domain`,value:i.domainName}),i.maliciousAddresses.slice(0,3).map(e=>K(Y,{label:`Found in: ${e.fieldPath}`,value:q(e.address),style:`color:#e74c3c`},e.address))]})]})}function Qt({confirmInput:e,isConfirmValid:t,onInput:n,onProceed:r}){return K(`div`,{class:`testudo-confirm-section`,children:[K(`label`,{class:`testudo-confirm-label`,for:`testudo-confirm-input`,children:[`Type `,K(`strong`,{style:`color:#e74c3c`,children:`I ACCEPT THE RISK`}),` to proceed`]}),K(`input`,{type:`text`,class:`testudo-confirm-input`,id:`testudo-confirm-input`,placeholder:`I ACCEPT THE RISK`,autocomplete:`off`,spellcheck:!1,value:e.value,onInput:e=>n(e.target.value)}),K(`button`,{type:`button`,class:`testudo-btn-danger-confirm${t.value?` enabled`:``}`,id:`testudo-eth-sign-proceed`,disabled:!t.value,onClick:r,children:[K(`span`,{class:`testudo-material-icon`,children:`warning`}),`Proceed with eth_sign`]})]})}function $t({context:e,confirmInput:t,isConfirmValid:n,onCancel:r,onProceed:i,onTrust:a,onEthSignProceed:o,onConfirmInput:s}){return K(`div`,{class:`testudo-buttons`,children:[K(`button`,{type:`button`,class:`testudo-btn-cancel`,id:`testudo-cancel`,onClick:r,children:[K(`span`,{class:`testudo-material-icon`,children:`shield`}),`Cancel (Safe)`]}),e===`eth-sign-danger`?K(Qt,{confirmInput:t,isConfirmValid:n,onInput:s,onProceed:o}):K(`div`,{class:`testudo-secondary-actions`,children:[K(`button`,{type:`button`,class:`testudo-btn-link`,id:`testudo-trust`,onClick:a,children:`Trust contract & Proceed`}),K(`button`,{type:`button`,class:`testudo-btn-danger`,id:`testudo-proceed`,onClick:i,children:[K(`span`,{children:`Proceed Anyway`}),K(`span`,{class:`testudo-material-icon`,children:`arrow_forward`})]})]})]})}function en(e){switch(e){case`eth-sign-danger`:return`Dangerous: eth_sign Detected`;case`blind-signature`:return`Blind Signature Request`;case`typed-data-scan`:return`Malicious Address in Signed Data`;case`nft-approval`:return`NFT Collection Approval Detected`;case`approval`:return`Token Approval Detected`;case`permit`:return`Permit Signature Detected`;case`transaction`:return`Malicious Recipient Detected`;default:return`Dangerous Contract Detected`}}function tn(e){return e===`HIGH`?`Suspicious Message Detected`:`Blind Signature Request`}function nn({context:e,analysis:t,intent:n}){let r=n?.headline??(e===`blind-signature`?tn(t.risk):en(e));return K(`div`,{class:`testudo-header`,children:[K(`div`,{class:`testudo-header-icon`,children:K(`span`,{class:`testudo-material-icon`,children:`gpp_maybe`})}),K(`div`,{class:`testudo-header-text`,children:[K(`h2`,{class:`testudo-title`,children:r}),K(`p`,{class:`testudo-subtitle`,children:rn(e,t)})]})]})}function rn(e,t){switch(e){case`eth-sign-danger`:return K(x,{children:[K(`strong`,{children:`eth_sign`}),` is deprecated and signs raw hashes. An attacker can craft a valid `,K(`strong`,{children:`transaction hash`}),` — signing it gives them full control of your wallet.`]});case`blind-signature`:return t.risk===`HIGH`?K(x,{children:[`This message contains `,K(`strong`,{children:`phishing patterns`}),` commonly used in scams.`]}):K(x,{children:[`You are signing `,K(`strong`,{children:`arbitrary data`}),` that cannot be verified.`]});case`typed-data-scan`:return K(x,{children:[`A `,K(`strong`,{children:`known malicious address`}),` was found in the data you are about to sign.`]});case`nft-approval`:return K(x,{children:[`You are granting `,K(`strong`,{children:`full collection access`}),` to another address.`]});case`approval`:return K(x,{children:[`You are granting `,K(`strong`,{children:`token spending rights`}),` to another address.`]});case`permit`:return K(x,{children:[`This signature grants `,K(`strong`,{children:`token spending rights`}),`!`]});case`transaction`:return K(x,{children:[`You are about to send funds to a `,K(`strong`,{children:`known scammer`}),` address.`]});default:return K(x,{children:[`We have intercepted a malicious `,K(`strong`,{children:`EIP-7702`}),` delegation request.`]})}}const an={auto_forwarder:{icon:`currency_exchange`,shortDesc:`Redirects incoming assets to external address`,format:`Auto-forwards ETH`},delegate_call:{icon:`call_split`,shortDesc:`Executes code in context of your wallet`,format:`Uses DELEGATECALL`},self_destruct:{icon:`delete_forever`,shortDesc:`Can destroy itself after draining funds`,format:`Can self-destruct`},unlimited_approval:{icon:`all_inclusive`,shortDesc:`Requests access to all your tokens`,format:`Unlimited token approval`},create2:{icon:`add_box`,shortDesc:`Can deploy contracts at predictable addresses`,format:`Uses CREATE2`},metamorphic:{icon:`swap_horiz`,shortDesc:`Code can change while keeping same address`,format:`Metamorphic contract`},chainid_branching:{icon:`public`,shortDesc:`Behavior changes based on network`,format:`Cross-chain behavior`},chainid_comparison:{icon:`public`,shortDesc:`May restrict behavior on specific chains`,format:`Network ID comparison`},chainid_read:{icon:`public`,shortDesc:`Reads network ID for conditional logic`,format:`Reads network ID`},token_drain_fallback:{icon:`token`,shortDesc:`Auto-drains tokens on any interaction`,format:`Token drain in fallback`},token_hardcoded_dest:{icon:`token`,shortDesc:`Sends funds to hardcoded attacker address`,format:`Hardcoded destination`},token_no_auth:{icon:`token`,shortDesc:`No signature verification for transfers`,format:`No access control`},token_replay_risk:{icon:`replay`,shortDesc:`Same signature can be reused multiple times`,format:`Replay attack risk`},token_approval_no_auth:{icon:`token`,shortDesc:`Unlimited access without verification`,format:`Unprotected approvals`},token_with_auth:{icon:`token`,shortDesc:`Has some security controls in place`,format:`Token transfers enabled`},nft_full_collection_access:{icon:`collections`,shortDesc:`Grants control over ALL NFTs in this collection`,format:`Full NFT collection access`},eth_sign_deprecated:{icon:`dangerous`,shortDesc:`eth_sign is deprecated and signs raw hashes without safety prefix`,format:`Deprecated: eth_sign`},blind_signature:{icon:`visibility_off`,shortDesc:`Signing arbitrary data without visibility into its purpose`,format:`Blind signature`},airdrop_scam:{icon:`card_giftcard`,shortDesc:`Message contains airdrop/reward scam language`,format:`Airdrop scam pattern`},verification_scam:{icon:`verified_user`,shortDesc:`Message impersonates wallet verification request`,format:`Verification scam pattern`},urgency:{icon:`timer`,shortDesc:`Message uses urgency pressure tactics`,format:`Urgency pressure tactic`},impersonation:{icon:`person_alert`,shortDesc:`Message impersonates a known brand or protocol`,format:`Brand impersonation`},financial_lure:{icon:`payments`,shortDesc:`Message contains financial lure language`,format:`Financial lure`},typed_data_malicious_address:{icon:`gpp_bad`,shortDesc:`A known malicious address is embedded in the signed data`,format:`Malicious address in signed data`},deployer_fresh:{icon:`new_releases`,shortDesc:`Deployed by a brand-new account with almost no history`,format:`Fresh deployer account`},deployer_low_nonce:{icon:`person_alert`,shortDesc:`Deployer account has very few transactions`,format:`Low-activity deployer`},deployer_new_contract:{icon:`schedule`,shortDesc:`Contract was deployed very recently`,format:`Recently deployed`},ETH_AUTO_FORWARDER:{icon:`currency_exchange`,shortDesc:`Known malicious ETH drainer contract`,format:`Known ETH drainer`},INFERNO_DRAINER:{icon:`local_fire_department`,shortDesc:`Known Inferno Drainer attack contract`,format:`Inferno Drainer`}};function on(e){return an[e]?.icon||`warning`}function sn(e){return an[e]?.shortDesc||`Suspicious behavior detected`}function cn(e){return an[e]?.format||e.replace(/_/g,` `)}function ln({threats:e}){return K(`div`,{class:`testudo-threats`,children:[K(`h3`,{class:`testudo-threats-title`,children:`Threats Detected`}),e.slice(0,3).map(e=>K(`div`,{class:`testudo-threat-item`,children:[K(`div`,{class:`testudo-threat-icon`,children:K(`span`,{class:`testudo-material-icon`,children:on(e)})}),K(`div`,{class:`testudo-threat-content`,children:[K(`span`,{class:`testudo-threat-name`,children:cn(e)}),K(`span`,{class:`testudo-threat-desc`,children:sn(e)})]})]},e))]})}function un(){let{visible:e,analysis:t,context:n,permitInfo:r,approvalInfo:i,nftApprovalInfo:a,blindSignatureInfo:o,typedDataScanInfo:s,intent:c}=U.value;return Se(()=>{if(!e)return;let t=e=>{e.key===`Escape`&&ft()};return document.addEventListener(`keydown`,t),()=>document.removeEventListener(`keydown`,t)},[e]),!e||!t?null:K(`div`,{id:`testudo-warning-overlay`,children:K(`div`,{class:`testudo-modal`,children:[K(nn,{context:n,analysis:t,intent:c}),K(It,{analysis:t}),K(Zt,{permitInfo:r,approvalInfo:i,nftApprovalInfo:a,blindSignatureInfo:o,typedDataScanInfo:s,intent:c}),K(ln,{threats:t.threats}),K(Ft,{address:t.address,context:n,copyIcon:lt,onCopy:gt}),K($t,{context:n,confirmInput:st,isConfirmValid:ct,onCancel:ft,onProceed:pt,onTrust:()=>mt(Nt),onEthSignProceed:ht,onConfirmInput:e=>{st.value=e}})]})})}const dn=`
#testudo-warning-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999999;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  animation: testudo-fade-in 0.3s ease;
}

@keyframes testudo-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes testudo-zoom-in {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}

.testudo-modal {
  background: #1a232e;
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  max-width: 480px;
  width: 90%;
  max-height: 90vh;
  color: white;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  overflow: hidden;
  animation: testudo-zoom-in 0.3s ease;
  display: flex;
  flex-direction: column;
}

.testudo-material-icon {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-style: normal;
  display: inline-block;
  line-height: 1;
  text-transform: none;
  letter-spacing: normal;
  word-wrap: normal;
  white-space: nowrap;
  direction: ltr;
  -webkit-font-smoothing: antialiased;
}

.testudo-header {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 32px 24px 16px;
  gap: 16px;
  flex-shrink: 0;
}

.testudo-header-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: rgba(231, 76, 60, 0.1);
  color: #e74c3c;
}

.testudo-header-icon .testudo-material-icon {
  font-size: 48px;
}

.testudo-header-text {
  text-align: center;
}

.testudo-title {
  font-size: 24px;
  font-weight: bold;
  color: #fff;
  margin: 0 0 8px 0;
  letter-spacing: -0.02em;
}

.testudo-subtitle {
  font-size: 14px;
  color: #97adc4;
  margin: 0;
  line-height: 1.5;
}

.testudo-subtitle strong {
  color: #fff;
  font-weight: 500;
}

.testudo-alert {
  margin: 0 24px;
  position: relative;
  overflow: hidden;
  border-radius: 8px;
  border: 1px solid rgba(231, 76, 60, 0.4);
  background: rgba(231, 76, 60, 0.1);
  padding: 20px;
}

.testudo-alert::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(231, 76, 60, 0.1) 0%, transparent 100%);
  pointer-events: none;
}

.testudo-alert-header {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #e74c3c;
  position: relative;
  z-index: 1;
}

.testudo-alert-header .testudo-material-icon {
  font-size: 20px;
}

.testudo-alert-title {
  font-size: 14px;
  font-weight: 700;
  letter-spacing: 0.05em;
  text-transform: uppercase;
}

.testudo-alert-medium {
  border-color: rgba(245, 158, 11, 0.4);
  background: rgba(245, 158, 11, 0.1);
}

.testudo-alert-medium::before {
  background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, transparent 100%);
}

.testudo-alert-medium .testudo-alert-header {
  color: #f59e0b;
}

.testudo-alert-description {
  color: rgba(255, 255, 255, 0.9);
  font-size: 14px;
  font-weight: 500;
  line-height: 1.6;
  margin-top: 8px;
  position: relative;
  z-index: 1;
}

.testudo-threats {
  padding: 16px 24px;
  margin-top: 16px;
  overflow-y: auto;
  max-height: 280px;
  flex-shrink: 1;
}

.testudo-threats-title {
  font-size: 12px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 12px;
  padding: 0 4px;
}

.testudo-threat-item {
  display: flex;
  align-items: center;
  gap: 16px;
  background: rgba(18, 26, 33, 0.5);
  border-radius: 8px;
  padding: 12px;
  border: 1px solid rgba(255, 255, 255, 0.05);
  margin-bottom: 8px;
}

.testudo-threat-item:last-child {
  margin-bottom: 0;
}

.testudo-threat-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: rgba(245, 158, 11, 0.1);
  color: #f59e0b;
  flex-shrink: 0;
}

.testudo-threat-icon .testudo-material-icon {
  font-size: 24px;
}

.testudo-threat-content {
  display: flex;
  flex-direction: column;
}

.testudo-threat-name {
  font-size: 14px;
  font-weight: 500;
  color: #fff;
  line-height: 1.4;
}

.testudo-threat-desc {
  font-size: 12px;
  color: #97adc4;
  margin-top: 2px;
}

.testudo-intent-action {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
  line-height: 1.6;
  margin-bottom: 8px;
  padding: 0 12px;
}

.testudo-address-section {
  margin: 8px 24px;
}

.testudo-address-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #121a21;
  border-radius: 4px;
  padding: 8px 12px;
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.testudo-address-label {
  font-size: 12px;
  font-weight: 500;
  color: #97adc4;
}

.testudo-address-value {
  display: flex;
  align-items: center;
  gap: 8px;
}

.testudo-address-text {
  font-family: 'Roboto Mono', ui-monospace, monospace;
  font-size: 14px;
  color: #fff;
  letter-spacing: 0.02em;
}

.testudo-copy-btn {
  background: none;
  border: none;
  color: #97adc4;
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.2s;
}

.testudo-copy-btn:hover {
  color: #fff;
}

.testudo-copy-btn .testudo-material-icon {
  font-size: 16px;
}

.testudo-buttons {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 8px 24px 24px;
  background: #1a232e;
  flex-shrink: 0;
}

.testudo-btn-cancel {
  width: 100%;
  background: #27ae60;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 16px 24px;
  font-size: 16px;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 4px 14px rgba(39, 174, 96, 0.2);
  transition: all 0.2s;
}

.testudo-btn-cancel:hover {
  background: #229954;
}

.testudo-btn-cancel:active {
  transform: scale(0.98);
}

.testudo-btn-cancel .testudo-material-icon {
  font-size: 20px;
}

.testudo-secondary-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 24px;
  padding-top: 8px;
}

.testudo-btn-link {
  background: none;
  border: none;
  color: #97adc4;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  padding: 8px;
  transition: color 0.2s;
  border-bottom: 1px solid transparent;
}

.testudo-btn-link:hover {
  color: #fff;
  border-bottom-color: rgba(255, 255, 255, 0.2);
}

.testudo-btn-danger {
  display: flex;
  align-items: center;
  gap: 4px;
  background: none;
  border: none;
  color: rgba(231, 76, 60, 0.7);
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  padding: 8px;
  transition: color 0.2s;
}

.testudo-btn-danger:hover {
  color: #e74c3c;
}

.testudo-btn-danger .testudo-material-icon {
  font-size: 16px;
  transition: transform 0.2s;
}

.testudo-btn-danger:hover .testudo-material-icon {
  transform: translateX(2px);
}

.testudo-confirm-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.testudo-confirm-label {
  font-size: 13px;
  color: #97adc4;
  font-weight: 500;
}

.testudo-confirm-input {
  width: 100%;
  background: #121a21;
  border: 1px solid rgba(231, 76, 60, 0.3);
  border-radius: 6px;
  padding: 12px;
  font-size: 14px;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color: #fff;
  outline: none;
  transition: border-color 0.2s;
  box-sizing: border-box;
}

.testudo-confirm-input:focus {
  border-color: rgba(231, 76, 60, 0.6);
}

.testudo-confirm-input::placeholder {
  color: rgba(151, 173, 196, 0.5);
}

.testudo-btn-danger-confirm {
  width: 100%;
  background: rgba(231, 76, 60, 0.15);
  color: rgba(231, 76, 60, 0.4);
  border: 1px solid rgba(231, 76, 60, 0.2);
  border-radius: 8px;
  padding: 14px 24px;
  font-size: 15px;
  font-weight: 600;
  cursor: not-allowed;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: all 0.2s;
}

.testudo-btn-danger-confirm.enabled {
  background: rgba(231, 76, 60, 0.9);
  color: #fff;
  border-color: #e74c3c;
  cursor: pointer;
}

.testudo-btn-danger-confirm.enabled:hover {
  background: #e74c3c;
}

.testudo-toast {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #1a232e;
  border: 1px solid rgba(245, 158, 11, 0.4);
  border-radius: 12px;
  padding: 16px 20px;
  color: white;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  z-index: 999998;
  max-width: 400px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  animation: testudo-slide-in 0.3s ease;
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

@keyframes testudo-slide-in {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

.testudo-toast-icon {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-size: 24px;
  color: #f59e0b;
}

.testudo-toast-content {
  flex: 1;
}

.testudo-toast-title {
  font-weight: 600;
  color: #f59e0b;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.testudo-toast-title .testudo-toast-icon-inline {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-size: 16px;
}

.testudo-toast-text {
  font-size: 13px;
  color: #97adc4;
  margin-top: 4px;
  line-height: 1.5;
}

.testudo-toast-dismiss {
  background: none;
  border: none;
  color: #97adc4;
  cursor: pointer;
  font-size: 12px;
  margin-top: 8px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: background 0.2s, color 0.2s;
}

.testudo-toast-dismiss:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.testudo-toast-unknown {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: #1a232e;
  border: 1px solid rgba(148, 163, 184, 0.4);
  border-radius: 12px;
  padding: 16px 20px;
  color: white;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  z-index: 999998;
  max-width: 400px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  animation: testudo-slide-in 0.3s ease;
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.testudo-toast-unknown-icon {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-size: 24px;
  color: #94a3b8;
}

.testudo-toast-unknown-content {
  flex: 1;
}

.testudo-toast-unknown-title {
  font-weight: 600;
  color: #94a3b8;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.testudo-toast-unknown-text {
  font-size: 13px;
  color: #97adc4;
  margin-top: 4px;
  line-height: 1.5;
}

.testudo-toast-unknown-address {
  font-family: 'Roboto Mono', monospace;
  font-size: 12px;
  color: #64748b;
  margin-top: 6px;
}

.testudo-toast-unknown-dismiss {
  background: none;
  border: none;
  color: #97adc4;
  cursor: pointer;
  font-size: 12px;
  margin-top: 8px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: background 0.2s, color 0.2s;
}

.testudo-toast-unknown-dismiss:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #fff;
}
`;function fn(){if(document.getElementById(`testudo-warning-styles`))return;let e=document.createElement(`style`);e.id=`testudo-warning-styles`,e.textContent=dn,document.head.appendChild(e)}const pn=BigInt(Bt),mn=BigInt(Vt),hn=BigInt(10)**BigInt(28);function gn(e){try{return BigInt(e)>=mn}catch{return!1}}function _n(e,t,n){try{let r=BigInt(e);if(r>=hn||r===pn||r===mn)return n?`Unlimited ${n}`:`Unlimited`;if(t!==null&&t>0){let e=BigInt(10)**BigInt(t),i=r/e,a=r%e;if(a===0n)return vn(i.toLocaleString(`en-US`),n);let o=a.toString().padStart(t,`0`),s=o.replace(/0+$/,``),c=s.length>6?s.slice(0,6):s;return vn(`${i.toLocaleString(`en-US`)}.${c}`,n)}return vn(r.toLocaleString(`en-US`),n)}catch{return n?`? ${n}`:e}}function vn(e,t){return t?`${e} ${t}`:e}function yn(e){if(gn(e))return`Never`;try{let t=Number(e);if(Number.isNaN(t)||t<=0)return e;let n=new Date(t*1e3),r=Date.now(),i=n.getTime()-r,a=n.toLocaleString(`en-US`,{month:`short`,day:`numeric`,year:`numeric`,hour:`2-digit`,minute:`2-digit`});if(i<0)return`${a} (expired)`;let o=Math.floor(i/6e4);if(o<60)return`${a} (in ${o}m)`;let s=Math.floor(o/60);if(s<24)return`${a} (in ${s}h)`;let c=Math.floor(s/24);return`${a} (in ${c}d)`}catch{return e}}const bn={1:`Ethereum`,10:`Optimism`,56:`BNB Chain`,100:`Gnosis`,137:`Polygon`,250:`Fantom`,324:`zkSync Era`,420:`Optimism Goerli`,8453:`Base`,42161:`Arbitrum One`,42170:`Arbitrum Nova`,43114:`Avalanche`,59144:`Linea`,534352:`Scroll`,7777777:`Zora`,11155111:`Sepolia`};function xn(e){if(e==null)return;let t=typeof e==`string`?Number(e):e;return bn[t]}function Sn(e,t){let n=q(e.spender),r=J(e.value),i=t?.symbol??e.tokenName??null,a=t?.decimals??null,o;o=e.value===`batch`?`Multiple tokens (batch)`:r?i?`Unlimited ${i}`:`Unlimited`:e.value&&a!==null?_n(e.value,a,i):e.value?i?`${e.value} (raw) ${i}`:e.value:`Unknown amount`;let s=[{label:`Spender`,value:n,emphasis:`danger`,mono:!0},{label:`Amount`,value:o,emphasis:r?`danger`:`warning`}];if(e.token&&s.push({label:`Token Contract`,value:q(e.token),mono:!0}),e.deadline){let t=yn(e.deadline);s.push({label:`Expires`,value:t,emphasis:gn(e.deadline)?`danger`:`info`})}let c=r?`Unlimited ${i??`Token`} Permit`:`${i??`Token`} Permit Request`;return{headline:c,action:`Allow ${n} to spend ${o}`,details:s}}function Cn(e,t){let n=q(e.spender),r=J(e.amount),i=t?.symbol??null,a=t?.decimals??null,o=r?i?`Unlimited ${i}`:`Unlimited`:_n(e.amount,a,i),s=[{label:`Spender`,value:n,emphasis:`danger`,mono:!0},{label:`Amount`,value:o,emphasis:r?`danger`:`warning`},{label:`Token Contract`,value:q(e.tokenAddress),mono:!0},{label:`Operation`,value:e.type===`approve`?`approve()`:e.type===`increaseAllowance`?`increaseAllowance()`:`decreaseAllowance()`,emphasis:`info`}],c=r?`Unlimited ${i??`Token`} Approval`:`${i??`Token`} Approval Request`;return{headline:c,action:`Allow ${n} to spend ${o}`,details:s}}function wn(e){let t=q(e.operator),n=e.collectionName??q(e.collectionAddress),r=[{label:`Operator`,value:t,emphasis:`danger`,mono:!0},{label:`Collection`,value:n},{label:`Access Level`,value:`Full Collection`,emphasis:`danger`}];return{headline:`NFT Collection Approval`,action:`Grant ${t} full access to your ${n}`,details:r}}function Tn(e,t,n){let r=q(e),i=xn(t),a=[{label:`Delegate`,value:r,emphasis:`danger`,mono:!0}];return i&&a.push({label:`Network`,value:i}),n&&n.risk!==`LOW`&&(a.push({label:`Deployer Activity`,value:`${n.deployerNonce} transactions`,emphasis:n.risk===`CRITICAL`?`danger`:`warning`}),a.push({label:`Contract Age`,value:En(n.contractAge),emphasis:n.contractAge<86400?`danger`:`info`})),{headline:`Wallet Delegation Request`,action:`Delegate wallet control to ${r}${i?` on ${i}`:``}`,details:a,chainName:i}}function En(e){return e<3600?`${Math.floor(e/60)} minutes`:e<86400?`${Math.floor(e/3600)} hours`:`${Math.floor(e/86400)} days`}function Dn(e){let t=q(e);return{headline:`Suspicious Transaction`,action:`Send funds to ${t}`,details:[{label:`Recipient`,value:t,emphasis:`danger`,mono:!0}]}}function On(e){let t=[{label:`Method`,value:e.type,emphasis:`warning`},{label:`Message${e.isHex?` (hex)`:``}`,value:e.messagePreview,mono:!0}];return{headline:`Blind Signature Request`,action:`Sign arbitrary data with ${e.type}`,details:t}}function kn(e){let t=[{label:`Primary Type`,value:e.primaryType}];e.domainName&&t.push({label:`Domain`,value:e.domainName});for(let n of e.maliciousAddresses.slice(0,3))t.push({label:`Found in: ${n.fieldPath}`,value:q(n.address),emphasis:`danger`,mono:!0});return{headline:`Malicious Address in Signed Data`,action:`Known malicious address found in ${e.primaryType}`,details:t}}function An(e){return{headline:`Dangerous: eth_sign Detected`,action:`Sign raw hash via deprecated eth_sign`,details:[{label:`Method`,value:`eth_sign (deprecated)`,emphasis:`danger`},{label:`Message`,value:e.messagePreview,mono:!0}]}}function jn(e,t){let n=e.context??`delegation`;switch(n){case`permit`:return e.permitInfo?Sn(e.permitInfo,t):null;case`approval`:return e.approvalInfo?Cn(e.approvalInfo,t):null;case`nft-approval`:return e.nftApprovalInfo?wn(e.nftApprovalInfo):null;case`delegation`:return Tn(e.analysis.address,void 0,e.analysis.deployerRisk);case`transaction`:return Dn(e.analysis.address);case`blind-signature`:return e.blindSignatureInfo?On(e.blindSignatureInfo):null;case`typed-data-scan`:return e.typedDataScanInfo?kn(e.typedDataScanInfo):null;case`eth-sign-danger`:return e.blindSignatureInfo?An(e.blindSignatureInfo):null;default:return null}}const Mn=500,Nn={"0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48":{symbol:`USDC`,decimals:6,name:`USD Coin`,isVerified:!0},"0xdac17f958d2ee523a2206206994597c13d831ec7":{symbol:`USDT`,decimals:6,name:`Tether USD`,isVerified:!0},"0x6b175474e89094c44da98b954eedeac495271d0f":{symbol:`DAI`,decimals:18,name:`Dai Stablecoin`,isVerified:!0},"0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2":{symbol:`WETH`,decimals:18,name:`Wrapped Ether`,isVerified:!0},"0x2260fac5e5542a773aa44fbcfedf7c193bc2c599":{symbol:`WBTC`,decimals:8,name:`Wrapped BTC`,isVerified:!0},"0x514910771af9ca656af840dff83e8264ecf986ca":{symbol:`LINK`,decimals:18,name:`ChainLink Token`,isVerified:!0},"0x1f9840a85d5af5bf1d1762f925bdaddc4201f984":{symbol:`UNI`,decimals:18,name:`Uniswap`,isVerified:!0},"0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9":{symbol:`AAVE`,decimals:18,name:`Aave Token`,isVerified:!0},"0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2":{symbol:`MKR`,decimals:18,name:`Maker`,isVerified:!0},"0xae7ab96520de3a18e5e111b5eaab095312d7fe84":{symbol:`stETH`,decimals:18,name:`Liquid staked Ether 2.0`,isVerified:!0},"0xbe9895146f7af43049ca1c1ae358b0541ea49704":{symbol:`cbETH`,decimals:18,name:`Coinbase Wrapped Staked ETH`,isVerified:!0},"0x853d955acef822db058eb8505911ed77f175b99e":{symbol:`FRAX`,decimals:18,name:`Frax`,isVerified:!0},"0x4fabb145d64652a948d72533023f6e7a623c7c53":{symbol:`BUSD`,decimals:18,name:`Binance USD`,isVerified:!0},"0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce":{symbol:`SHIB`,decimals:18,name:`SHIBA INU`,isVerified:!0}},X=new Map;function Pn(e){return X.get(e.toLowerCase())??null}async function Fn(e){let t=e.toLowerCase(),n=X.get(t);if(n)return n;let r=Nn[t];if(r){let e={address:t,...r};return X.set(t,e),e}let i=await Mt(t),a={address:t,name:i.name,symbol:i.symbol,decimals:i.decimals,isVerified:!1};return In(t,a),a}function In(e,t){X.size>=Mn&&X.clear(),X.set(e,t)}function Ln(e){return e===`personal_sign`}function Rn(e,t){if(!Array.isArray(t)||t.length<2)return null;let[n,r]=t,i=e===`personal_sign`?String(n):String(r),a=e===`personal_sign`?String(r):String(n);if(!/^0x[a-fA-F0-9]{40}$/.test(a))return null;let o=/^0x[a-fA-F0-9]+$/.test(i),s=i;if(o&&i.length>2)try{let e=i.slice(2,4002),t=e.match(/.{1,2}/g);if(t){let e=t.map(e=>String.fromCharCode(parseInt(e,16))).join(``);/^[\x20-\x7E\s]+$/.test(e)&&(s=e)}}catch{}let c=s;return c.length>100&&(c=`${c.slice(0,97)}...`),{type:e,message:i,decodedMessage:s,messagePreview:c,signer:a.toLowerCase(),isHex:o}}const zn=[{category:`airdrop_scam`,regex:/claim\s+(your\s+)?airdrop/i,score:3},{category:`airdrop_scam`,regex:/free\s+tokens?/i,score:3},{category:`airdrop_scam`,regex:/claim\s+(your\s+)?reward/i,score:3},{category:`verification_scam`,regex:/verify\s+(your\s+)?wallet/i,score:3},{category:`verification_scam`,regex:/confirm\s+(your\s+)?ownership/i,score:3},{category:`verification_scam`,regex:/security\s+(check|verification)/i,score:3},{category:`urgency`,regex:/expires?\s+in/i,score:2},{category:`urgency`,regex:/act\s+now/i,score:2},{category:`urgency`,regex:/limited\s+time/i,score:2},{category:`urgency`,regex:/within\s+\d+\s+(hour|minute)/i,score:2},{category:`impersonation`,regex:/opensea/i,score:2},{category:`impersonation`,regex:/metamask/i,score:2},{category:`impersonation`,regex:/uniswap/i,score:2},{category:`impersonation`,regex:/coinbase/i,score:2},{category:`financial_lure`,regex:/you\s+(have\s+)?won/i,score:2},{category:`financial_lure`,regex:/prize/i,score:2},{category:`financial_lure`,regex:/bonus\s+token/i,score:2}];function Bn(e){let t=0,n=new Set;for(let r of zn)r.regex.test(e)&&(t+=r.score,n.add(r.category));let r=Array.from(n),i=t>=3?`HIGH`:t>=1?`MEDIUM`:`INFO`;return{score:t,patterns:r,risk:i}}function Vn(e){return!(!e.types?.Authorization||e.primaryType!==`Authorization`||!e.message?.address)}function Hn(e){let t=e.primaryType;return t===`Permit`||t===`PermitSingle`||t===`PermitBatch`||t===`PermitTransferFrom`||t===`PermitWitnessTransferFrom`}function Z(e){return typeof e!=`string`||!/^0x[a-fA-F0-9]{40}$/.test(e)?null:e.toLowerCase()}function Un(e){let t=[],n=new Set,r=10,i=100,a=Z(e.domain?.verifyingContract);a&&(n.add(a),t.push({address:a,fieldPath:`domain.verifyingContract`}));let o=e.types;function s(e,a,c,l){if(l>r||t.length>=i||a===`EIP712Domain`)return;let u=o[a];if(!(!Array.isArray(u)||typeof e!=`object`||!e))for(let r of u){let a=e[r.name],u=c?`${c}.${r.name}`:r.name;if(r.type===`address`){let e=Z(a);e&&!n.has(e)&&(n.add(e),t.push({address:e,fieldPath:u}))}else if(r.type===`address[]`&&Array.isArray(a))for(let e=0;e<a.length&&t.length<i;e++){let r=Z(a[e]);r&&!n.has(r)&&(n.add(r),t.push({address:r,fieldPath:`${u}[${e}]`}))}else if(r.type.endsWith(`[]`)){let e=r.type.slice(0,-2);if(o[e]&&Array.isArray(a))for(let n=0;n<a.length&&t.length<i;n++)s(a[n],e,`${u}[${n}]`,l+1)}else o[r.type]&&s(a,r.type,u,l+1)}}return s(e.message,e.primaryType,`message`,0),t}function Wn(e){let t=e.types[e.primaryType];return Array.isArray(t)?t.some(e=>e.name===`holder`)&&t.some(e=>e.name===`allowed`):!1}function Gn(e){let{primaryType:t,message:n,domain:r}=e;if(t===`Permit`){let t=Z(n.spender);if(!t)return null;let i=Wn(e);return{type:i?`dai-permit`:`permit`,spender:t,value:i?n.allowed===!0?`unlimited`:`0`:String(n.value??``),deadline:n.deadline==null?n.expiry==null?void 0:String(n.expiry):String(n.deadline),token:r?.verifyingContract,tokenName:r?.name}}if(t===`PermitSingle`){let e=Z(n.spender);if(!e)return null;let t=n.details;return{type:`permit2-single`,spender:e,value:t?.amount==null?void 0:String(t.amount),deadline:n.sigDeadline==null?void 0:String(n.sigDeadline),token:typeof t?.token==`string`?t.token:void 0}}if(t===`PermitBatch`){let e=Z(n.spender);if(!e)return null;let t=n.details;if(!Array.isArray(t)||t.length===0)return null;let r=t.some(e=>J(e.amount==null?void 0:String(e.amount)));return{type:`permit2-batch`,spender:e,deadline:n.sigDeadline==null?void 0:String(n.sigDeadline),token:typeof t[0]?.token==`string`?t[0].token:void 0,value:r?`unlimited`:`batch`}}if(t===`PermitTransferFrom`||t===`PermitWitnessTransferFrom`){let e=Z(n.spender);if(!e)return null;let r=n.permitted;return{type:t===`PermitTransferFrom`?`permit2-transfer`:`permit2-witness-transfer`,spender:e,value:r?.amount==null?void 0:String(r.amount),deadline:n.deadline==null?void 0:String(n.deadline),token:typeof r?.token==`string`?r.token:void 0}}return null}let Q=null;function Kn(e){le(K(x,{children:[K(un,{}),K(Et,{}),K(Dt,{})]}),e)}function qn(){if(!Q?.isConnected){if(fn(),Q&&!Q.isConnected){document.body.appendChild(Q);return}Q=document.createElement(`div`),Q.id=`testudo-root`,document.body.appendChild(Q),Kn(Q)}}async function Jn(e,t=2e3){let n=Pn(e);if(n)return n;try{return await Promise.race([Fn(e),new Promise(e=>setTimeout(()=>e(null),t))])}catch{return null}}async function $(e,t){let n=null;t&&(n=await Jn(t));let r=jn(e,n);return qn(),ut({...e,intent:r??void 0})}function Yn(e){qn(),vt(e)}function Xn(e){qn(),xt(e)}let Zn=!1;function Qn(){if(Zn||window.ethereum===void 0)return;console.log(`[Testudo] 🛡️ Initializing EIP-7702 protection...`),Zn=!0;let e=window.ethereum.request.bind(window.ethereum);try{window.ethereum.request=async t=>{if(t.method===`eth_sendTransaction`)try{let n=t.params?.[0],r=n?.to,i=n?.data;if(r&&i&&Kt(i)){let n=qt(i,r);if(n){if(console.log(`[Testudo] NFT setApprovalForAll detected`),!n.approved)return console.log(`[Testudo] NFT approval revocation detected, passing through`),e(t);let r=await kt(n.operator);if(r.risk===`CRITICAL`||r.risk===`HIGH`){let i=await $({analysis:r,context:`nft-approval`,nftApprovalInfo:n});if(!i)throw Error(`Testudo: NFT approval blocked by user - malicious operator detected`);return e(t)}if(r.whitelisted)return console.log(`[Testudo] Operator is whitelisted, passing through`),e(t);let i=Jt(n.operator);if(i)return console.log(`[Testudo] Known marketplace: ${i}`),e(t);let a={...r,risk:`HIGH`,threats:[`nft_full_collection_access`,...r.threats],blocked:!0},o=await $({analysis:a,context:`nft-approval`,nftApprovalInfo:n});if(!o)throw Error(`Testudo: NFT approval blocked by user - unknown operator`);return e(t)}}if(r&&i&&Ht(i)){let n=Ut(i,r);if(n){if(console.log(`[Testudo] Token approval detected:`,n.type),Gt(n.amount))return console.log(`[Testudo] Approval revocation detected, passing through`),e(t);let r=await kt(n.spender),i=J(n.amount);if(r.risk===`CRITICAL`||r.risk===`HIGH`){let e=await $({analysis:r,context:`approval`,approvalInfo:n},n.tokenAddress);if(!e)throw Error(`Testudo: Approval blocked by user - malicious spender detected`)}else if(i){let e={...r,risk:`HIGH`,threats:[`unlimited_approval`,...r.threats],blocked:!0},t=await $({analysis:e,context:`approval`,approvalInfo:n},n.tokenAddress);if(!t)throw Error(`Testudo: Approval blocked by user - unlimited amount`)}return e(t)}}if(r&&/^0x[a-fA-F0-9]{40}$/.test(r)){let e=await kt(r);if(e.risk===`CRITICAL`||e.risk===`HIGH`){let t=await $({analysis:e,context:`transaction`});if(!t)throw Error(`Testudo: Transaction blocked by user - malicious recipient detected`)}}return e(t)}catch(n){if(n instanceof Error&&n.message.includes(`Testudo`))throw n;return console.error(`[Testudo] Error checking transaction:`,n),e(t)}if(t.method===`eth_sign`){let n=Rn(`eth_sign`,t.params);if(!n)throw console.warn(`[Testudo] eth_sign blocked — malformed parameters`),Error(`Testudo: eth_sign blocked — malformed parameters`);console.log(`[Testudo] eth_sign detected — CRITICAL: deprecated method signs raw hashes`);let r={address:n.signer,risk:`CRITICAL`,threats:[`eth_sign_deprecated`,`blind_signature`],warnings:[{type:`ETH_SIGN_DEPRECATED`,title:`Deprecated: eth_sign`,description:`eth_sign signs a raw 32-byte hash without any safety prefix. An attacker can craft a valid transaction hash, and signing it gives them full control to execute that transaction from your wallet.`,severity:`CRITICAL`}],blocked:!0,whitelisted:!1},i=await $({analysis:r,context:`eth-sign-danger`,blindSignatureInfo:n});if(!i)throw Error(`Testudo: eth_sign blocked by user — deprecated method rejected`);return e(t)}if(Ln(t.method)){let n=Rn(t.method,t.params);if(n){console.log(`[Testudo] Blind signature detected: ${n.type}`);let e=Bn(n.decodedMessage),t=e.risk===`HIGH`,r=t?[...e.patterns,`blind_signature`]:[`blind_signature`],i={address:n.signer,risk:t?`HIGH`:`MEDIUM`,threats:r,warnings:[{type:t?`PHISHING_PATTERN`:`BLIND_SIGNATURE`,title:t?`Suspicious Message Detected`:`Blind Signature Request`,description:t?`This message contains patterns commonly used in phishing attacks.`:`You are signing data that cannot be verified. This could authorize actions you cannot see.`,severity:t?`HIGH`:`MEDIUM`}],blocked:t,whitelisted:!1},a=await $({analysis:i,context:`blind-signature`,blindSignatureInfo:n});if(!a)throw Error(`Testudo: ${n.type} blocked by user - blind signature rejected`)}return e(t)}if(t.method!==`eth_signTypedData_v4`&&t.method!==`eth_signTypedData_v3`)return e(t);try{let n=t.params,r=n[1],i=typeof r==`string`?JSON.parse(r):r;if(Hn(i)){let n=Gn(i);if(n){console.log(`[Testudo] Permit signature detected:`,n.type);let r=await kt(n.spender),i=J(n.value);if(r.risk===`CRITICAL`||r.risk===`HIGH`){let e=await $({analysis:r,context:`permit`,permitInfo:n},n.token);if(!e)throw Error(`Testudo: Permit blocked by user - malicious spender detected`)}else if(i){let e={...r,risk:`HIGH`,threats:[`unlimited_approval`,...r.threats],blocked:!0},t=await $({analysis:e,context:`permit`,permitInfo:n},n.token);if(!t)throw Error(`Testudo: Permit blocked by user - unlimited approval`)}return e(t)}}if(!Vn(i)){try{let e=Un(i);if(e.length>0){let{malicious:t,results:n}=await At(e);if(t.length>0){let e=t[0].address.toLowerCase(),r=n.get(e),a={address:e,risk:`CRITICAL`,threats:[`typed_data_malicious_address`,...r?.threats||[]],warnings:[{type:`TYPED_DATA_MALICIOUS_ADDRESS`,title:`Malicious Address in Signed Data`,description:`A known malicious address was found in the data you are about to sign.`,severity:`CRITICAL`}],blocked:!0,whitelisted:!1},o={maliciousAddresses:t,primaryType:i.primaryType,domainName:i.domain?.name},s=await $({analysis:a,context:`typed-data-scan`,typedDataScanInfo:o});if(!s)throw Error(`Testudo: Typed data blocked by user - malicious address in signed data`)}}}catch(e){if(e instanceof Error&&e.message.includes(`Testudo`))throw e;console.error(`[Testudo] Error scanning typed data:`,e)}return e(t)}console.log(`[Testudo] 🔍 EIP-7702 authorization detected!`);let a=i.message.address;console.log(`[Testudo] Delegate address:`,a);let o=await jt(a);if(console.log(`[Testudo] Analysis result:`,o),o.risk===`CRITICAL`||o.risk===`HIGH`){let e=await $({analysis:o});if(!e)throw console.log(`[Testudo] ❌ User rejected dangerous delegation`),Error(`Testudo: Delegation blocked by user - dangerous contract detected`);console.log(`[Testudo] ⚠️ User proceeded despite warning`)}else o.risk===`MEDIUM`?Yn(o):o.risk===`UNKNOWN`&&Xn(o);return e(t)}catch(n){if(n instanceof Error&&n.message.includes(`Testudo`))throw n;return console.error(`[Testudo] Error analyzing request:`,n),e(t)}}}catch(e){console.error(`[Testudo] Failed to wrap provider (frozen object?):`,e),Zn=!1;return}console.log(`[Testudo] ✅ Protection active`)}let $n;window.ethereum!==void 0&&($n=window.ethereum),Qn();let er=window.ethereum;Object.defineProperty(window,`ethereum`,{configurable:!0,enumerable:!0,get(){return er},set(e){e!==er&&e!==$n?(er=e,Zn=!1,$n=e,Qn()):er=e}});