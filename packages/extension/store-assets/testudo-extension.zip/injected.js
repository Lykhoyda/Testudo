var e,t,n,r,i,a,o,s,c,l,u,d,f,p={},m=[],h=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,g=Array.isArray;function _(e,t){for(var n in t)e[n]=t[n];return e}function v(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function y(t,n,r){var i,a,o,s={};for(o in n)o==`key`?i=n[o]:o==`ref`?a=n[o]:s[o]=n[o];if(arguments.length>2&&(s.children=arguments.length>3?e.call(arguments,2):r),typeof t==`function`&&t.defaultProps!=null)for(o in t.defaultProps)s[o]===void 0&&(s[o]=t.defaultProps[o]);return b(t,s,i,a,null)}function b(e,r,i,a,o){var s={type:e,props:r,key:i,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++n,__i:-1,__u:0};return o==null&&t.vnode!=null&&t.vnode(s),s}function x(e){return e.children}function S(e,t){this.props=e,this.context=t}function C(e,t){if(t==null)return e.__?C(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type==`function`?C(e):null}function w(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return w(e)}}function T(e){(!e.__d&&(e.__d=!0)&&i.push(e)&&!E.__r++||a!=t.debounceRendering)&&((a=t.debounceRendering)||o)(E)}function E(){for(var e,n,r,a,o,c,l,u=1;i.length;)i.length>u&&i.sort(s),e=i.shift(),u=i.length,e.__d&&(r=void 0,a=void 0,o=(a=(n=e).__v).__e,c=[],l=[],n.__P&&((r=_({},a)).__v=a.__v+1,t.vnode&&t.vnode(r),A(n.__P,r,a,n.__n,n.__P.namespaceURI,32&a.__u?[o]:null,c,o??C(a),!!(32&a.__u),l),r.__v=a.__v,r.__.__k[r.__i]=r,ae(c,r,l),a.__e=a.__=null,r.__e!=o&&w(r)));E.__r=0}function ee(e,t,n,r,i,a,o,s,c,l,u){var d,f,h,g,_,v,y,b=r&&r.__k||m,x=t.length;for(c=te(n,t,b,c,x),d=0;d<x;d++)(h=n.__k[d])!=null&&(f=h.__i==-1?p:b[h.__i]||p,h.__i=d,v=A(e,h,f,i,a,o,s,c,l,u),g=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&ce(f.ref,null,h),u.push(h.ref,h.__c||g,h)),_==null&&g!=null&&(_=g),(y=!!(4&h.__u))||f.__k===h.__k?c=D(h,c,e,y):typeof h.type==`function`&&v!==void 0?c=v:g&&(c=g.nextSibling),h.__u&=-7);return n.__e=_,c}function te(e,t,n,r,i){var a,o,s,c,l,u=n.length,d=u,f=0;for(e.__k=Array(i),a=0;a<i;a++)(o=t[a])!=null&&typeof o!=`boolean`&&typeof o!=`function`?(typeof o==`string`||typeof o==`number`||typeof o==`bigint`||o.constructor==String?o=e.__k[a]=b(null,o,null,null,null):g(o)?o=e.__k[a]=b(x,{children:o},null,null,null):o.constructor===void 0&&o.__b>0?o=e.__k[a]=b(o.type,o.props,o.key,o.ref?o.ref:null,o.__v):e.__k[a]=o,c=a+f,o.__=e,o.__b=e.__b+1,s=null,(l=o.__i=ne(o,n,c,d))!=-1&&(d--,(s=n[l])&&(s.__u|=2)),s==null||s.__v==null?(l==-1&&(i>u?f--:i<u&&f++),typeof o.type!=`function`&&(o.__u|=4)):l!=c&&(l==c-1?f--:l==c+1?f++:(l>c?f--:f++,o.__u|=4))):e.__k[a]=null;if(d)for(a=0;a<u;a++)(s=n[a])!=null&&!(2&s.__u)&&(s.__e==r&&(r=C(s)),le(s,s));return r}function D(e,t,n,r){var i,a;if(typeof e.type==`function`){for(i=e.__k,a=0;i&&a<i.length;a++)i[a]&&(i[a].__=e,t=D(i[a],t,n,r));return t}e.__e!=t&&(r&&(t&&e.type&&!t.parentNode&&(t=C(e)),n.insertBefore(e.__e,t||null)),t=e.__e);do t&&=t.nextSibling;while(t!=null&&t.nodeType==8);return t}function ne(e,t,n,r){var i,a,o,s=e.key,c=e.type,l=t[n],u=l!=null&&(2&l.__u)==0;if(l===null&&s==null||u&&s==l.key&&c==l.type)return n;if(r>(u?1:0)){for(i=n-1,a=n+1;i>=0||a<t.length;)if((l=t[o=i>=0?i--:a++])!=null&&!(2&l.__u)&&s==l.key&&c==l.type)return o}return-1}function O(e,t,n){t[0]==`-`?e.setProperty(t,n??``):e[t]=n==null?``:typeof n!=`number`||h.test(t)?n:n+`px`}function k(e,t,n,r,i){var a,o;n:if(t==`style`)if(typeof n==`string`)e.style.cssText=n;else{if(typeof r==`string`&&(e.style.cssText=r=``),r)for(t in r)n&&t in n||O(e.style,t,``);if(n)for(t in n)r&&n[t]==r[t]||O(e.style,t,n[t])}else if(t[0]==`o`&&t[1]==`n`)a=t!=(t=t.replace(c,`$1`)),o=t.toLowerCase(),t=o in e||t==`onFocusOut`||t==`onFocusIn`?o.slice(2):t.slice(2),e.l||={},e.l[t+a]=n,n?r?n.u=r.u:(n.u=l,e.addEventListener(t,a?d:u,a)):e.removeEventListener(t,a?d:u,a);else{if(i==`http://www.w3.org/2000/svg`)t=t.replace(/xlink(H|:h)/,`h`).replace(/sName$/,`s`);else if(t!=`width`&&t!=`height`&&t!=`href`&&t!=`list`&&t!=`form`&&t!=`tabIndex`&&t!=`download`&&t!=`rowSpan`&&t!=`colSpan`&&t!=`role`&&t!=`popover`&&t in e)try{e[t]=n??``;break n}catch{}typeof n==`function`||(n==null||!1===n&&t[4]!=`-`?e.removeAttribute(t):e.setAttribute(t,t==`popover`&&n==1?``:n))}}function re(e){return function(n){if(this.l){var r=this.l[n.type+e];if(n.t==null)n.t=l++;else if(n.t<r.u)return;return r(t.event?t.event(n):n)}}}function A(e,n,r,i,a,o,s,c,l,u){var d,f,p,m,h,y,b,C,w,T,E,te,D,ne,O,k,re,A=n.type;if(n.constructor!==void 0)return null;128&r.__u&&(l=!!(32&r.__u),o=[c=n.__e=r.__e]),(d=t.__b)&&d(n);n:if(typeof A==`function`)try{if(C=n.props,w=`prototype`in A&&A.prototype.render,T=(d=A.contextType)&&i[d.__c],E=d?T?T.props.value:d.__:i,r.__c?b=(f=n.__c=r.__c).__=f.__E:(w?n.__c=f=new A(C,E):(n.__c=f=new S(C,E),f.constructor=A,f.render=ue),T&&T.sub(f),f.state||={},f.__n=i,p=f.__d=!0,f.__h=[],f._sb=[]),w&&f.__s==null&&(f.__s=f.state),w&&A.getDerivedStateFromProps!=null&&(f.__s==f.state&&(f.__s=_({},f.__s)),_(f.__s,A.getDerivedStateFromProps(C,f.__s))),m=f.props,h=f.state,f.__v=n,p)w&&A.getDerivedStateFromProps==null&&f.componentWillMount!=null&&f.componentWillMount(),w&&f.componentDidMount!=null&&f.__h.push(f.componentDidMount);else{if(w&&A.getDerivedStateFromProps==null&&C!==m&&f.componentWillReceiveProps!=null&&f.componentWillReceiveProps(C,E),n.__v==r.__v||!f.__e&&f.shouldComponentUpdate!=null&&!1===f.shouldComponentUpdate(C,f.__s,E)){for(n.__v!=r.__v&&(f.props=C,f.state=f.__s,f.__d=!1),n.__e=r.__e,n.__k=r.__k,n.__k.some(function(e){e&&(e.__=n)}),te=0;te<f._sb.length;te++)f.__h.push(f._sb[te]);f._sb=[],f.__h.length&&s.push(f);break n}f.componentWillUpdate!=null&&f.componentWillUpdate(C,f.__s,E),w&&f.componentDidUpdate!=null&&f.__h.push(function(){f.componentDidUpdate(m,h,y)})}if(f.context=E,f.props=C,f.__P=e,f.__e=!1,D=t.__r,ne=0,w){for(f.state=f.__s,f.__d=!1,D&&D(n),d=f.render(f.props,f.state,f.context),O=0;O<f._sb.length;O++)f.__h.push(f._sb[O]);f._sb=[]}else do f.__d=!1,D&&D(n),d=f.render(f.props,f.state,f.context),f.state=f.__s;while(f.__d&&++ne<25);f.state=f.__s,f.getChildContext!=null&&(i=_(_({},i),f.getChildContext())),w&&!p&&f.getSnapshotBeforeUpdate!=null&&(y=f.getSnapshotBeforeUpdate(m,h)),k=d,d!=null&&d.type===x&&d.key==null&&(k=oe(d.props.children)),c=ee(e,g(k)?k:[k],n,r,i,a,o,s,c,l,u),f.base=n.__e,n.__u&=-161,f.__h.length&&s.push(f),b&&(f.__E=f.__=null)}catch(e){if(n.__v=null,l||o!=null)if(e.then){for(n.__u|=l?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;o[o.indexOf(c)]=null,n.__e=c}else{for(re=o.length;re--;)v(o[re]);ie(n)}else n.__e=r.__e,n.__k=r.__k,e.then||ie(n);t.__e(e,n,r)}else o==null&&n.__v==r.__v?(n.__k=r.__k,n.__e=r.__e):c=n.__e=se(r.__e,n,r,i,a,o,s,l,u);return(d=t.diffed)&&d(n),128&n.__u?void 0:c}function ie(e){e&&e.__c&&(e.__c.__e=!0),e&&e.__k&&e.__k.forEach(ie)}function ae(e,n,r){for(var i=0;i<r.length;i++)ce(r[i],r[++i],r[++i]);t.__c&&t.__c(n,e),e.some(function(n){try{e=n.__h,n.__h=[],e.some(function(e){e.call(n)})}catch(e){t.__e(e,n.__v)}})}function oe(e){return typeof e!=`object`||!e||e.__b&&e.__b>0?e:g(e)?e.map(oe):_({},e)}function se(n,r,i,a,o,s,c,l,u){var d,f,m,h,_,y,b,x=i.props||p,S=r.props,w=r.type;if(w==`svg`?o=`http://www.w3.org/2000/svg`:w==`math`?o=`http://www.w3.org/1998/Math/MathML`:o||=`http://www.w3.org/1999/xhtml`,s!=null){for(d=0;d<s.length;d++)if((_=s[d])&&`setAttribute`in _==!!w&&(w?_.localName==w:_.nodeType==3)){n=_,s[d]=null;break}}if(n==null){if(w==null)return document.createTextNode(S);n=document.createElementNS(o,w,S.is&&S),l&&(t.__m&&t.__m(r,s),l=!1),s=null}if(w==null)x===S||l&&n.data==S||(n.data=S);else{if(s&&=e.call(n.childNodes),!l&&s!=null)for(x={},d=0;d<n.attributes.length;d++)x[(_=n.attributes[d]).name]=_.value;for(d in x)if(_=x[d],d!=`children`){if(d==`dangerouslySetInnerHTML`)m=_;else if(!(d in S)){if(d==`value`&&`defaultValue`in S||d==`checked`&&`defaultChecked`in S)continue;k(n,d,null,_,o)}}for(d in S)_=S[d],d==`children`?h=_:d==`dangerouslySetInnerHTML`?f=_:d==`value`?y=_:d==`checked`?b=_:l&&typeof _!=`function`||x[d]===_||k(n,d,_,x[d],o);if(f)l||m&&(f.__html==m.__html||f.__html==n.innerHTML)||(n.innerHTML=f.__html),r.__k=[];else if(m&&(n.innerHTML=``),ee(r.type==`template`?n.content:n,g(h)?h:[h],r,i,a,w==`foreignObject`?`http://www.w3.org/1999/xhtml`:o,s,c,s?s[0]:i.__k&&C(i,0),l,u),s!=null)for(d=s.length;d--;)v(s[d]);l||(d=`value`,w==`progress`&&y==null?n.removeAttribute(`value`):y!=null&&(y!==n[d]||w==`progress`&&!y||w==`option`&&y!=x[d])&&k(n,d,y,x[d],o),d=`checked`,b!=null&&b!=n[d]&&k(n,d,b,x[d],o))}return n}function ce(e,n,r){try{if(typeof e==`function`){var i=typeof e.__u==`function`;i&&e.__u(),i&&n==null||(e.__u=e(n))}else e.current=n}catch(e){t.__e(e,r)}}function le(e,n,r){var i,a;if(t.unmount&&t.unmount(e),(i=e.ref)&&(i.current&&i.current!=e.__e||ce(i,null,n)),(i=e.__c)!=null){if(i.componentWillUnmount)try{i.componentWillUnmount()}catch(e){t.__e(e,n)}i.base=i.__P=null}if(i=e.__k)for(a=0;a<i.length;a++)i[a]&&le(i[a],n,r||typeof e.type!=`function`);r||v(e.__e),e.__c=e.__=e.__e=void 0}function ue(e,t,n){return this.constructor(e,n)}function de(n,r,i){var a,o,s,c;r==document&&(r=document.documentElement),t.__&&t.__(n,r),o=(a=typeof i==`function`)?null:i&&i.__k||r.__k,s=[],c=[],A(r,n=(!a&&i||r).__k=y(x,null,[n]),o||p,p,r.namespaceURI,!a&&i?[i]:o?null:r.firstChild?e.call(r.childNodes):null,s,!a&&i?i:o?o.__e:r.firstChild,a,c),ae(s,n,c)}e=m.slice,t={__e:function(e,t,n,r){for(var i,a,o;t=t.__;)if((i=t.__c)&&!i.__)try{if((a=i.constructor)&&a.getDerivedStateFromError!=null&&(i.setState(a.getDerivedStateFromError(e)),o=i.__d),i.componentDidCatch!=null&&(i.componentDidCatch(e,r||{}),o=i.__d),o)return i.__E=i}catch(t){e=t}throw e}},n=0,r=function(e){return e!=null&&e.constructor===void 0},S.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=_({},this.state),typeof e==`function`&&(e=e(_({},n),this.props)),e&&_(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),T(this))},S.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),T(this))},S.prototype.render=x,i=[],o=typeof Promise==`function`?Promise.prototype.then.bind(Promise.resolve()):setTimeout,s=function(e,t){return e.__v.__b-t.__v.__b},E.__r=0,c=/(PointerCapture)$|Capture$/i,l=0,u=re(!1),d=re(!0),f=0;var fe,j,pe,me,he=0,ge=[],M=t,_e=M.__b,ve=M.__r,ye=M.diffed,be=M.__c,xe=M.unmount,Se=M.__;function Ce(e,t){M.__h&&M.__h(j,e,he||t),he=0;var n=j.__H||={__:[],__h:[]};return e>=n.__.length&&n.__.push({}),n.__[e]}function we(e,t){var n=Ce(fe++,3);!M.__s&&je(n.__H,t)&&(n.__=e,n.u=t,j.__H.__h.push(n))}function Te(e,t){var n=Ce(fe++,7);return je(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function Ee(){for(var e;e=ge.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ke),e.__H.__h.forEach(Ae),e.__H.__h=[]}catch(t){e.__H.__h=[],M.__e(t,e.__v)}}M.__b=function(e){j=null,_e&&_e(e)},M.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Se&&Se(e,t)},M.__r=function(e){ve&&ve(e),fe=0;var t=(j=e.__c).__H;t&&(pe===j?(t.__h=[],j.__h=[],t.__.forEach(function(e){e.__N&&(e.__=e.__N),e.u=e.__N=void 0})):(t.__h.forEach(ke),t.__h.forEach(Ae),t.__h=[],fe=0)),pe=j},M.diffed=function(e){ye&&ye(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(ge.push(t)!==1&&me===M.requestAnimationFrame||((me=M.requestAnimationFrame)||Oe)(Ee)),t.__H.__.forEach(function(e){e.u&&(e.__H=e.u),e.u=void 0})),pe=j=null},M.__c=function(e,t){t.some(function(e){try{e.__h.forEach(ke),e.__h=e.__h.filter(function(e){return!e.__||Ae(e)})}catch(n){t.some(function(e){e.__h&&=[]}),t=[],M.__e(n,e.__v)}}),be&&be(e,t)},M.unmount=function(e){xe&&xe(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(e){try{ke(e)}catch(e){t=e}}),n.__H=void 0,t&&M.__e(t,n.__v))};var De=typeof requestAnimationFrame==`function`;function Oe(e){var t,n=function(){clearTimeout(r),De&&cancelAnimationFrame(t),setTimeout(e)},r=setTimeout(n,35);De&&(t=requestAnimationFrame(n))}function ke(e){var t=j,n=e.__c;typeof n==`function`&&(e.__c=void 0,n()),j=t}function Ae(e){var t=j;e.__c=e.__(),j=t}function je(e,t){return!e||e.length!==t.length||t.some(function(t,n){return t!==e[n]})}var Me=Symbol.for(`preact-signals`);function Ne(){if(P>1)P--;else{for(var e,t=!1;Le!==void 0;){var n=Le;for(Le=void 0,Re++;n!==void 0;){var r=n.o;if(n.o=void 0,n.f&=-3,!(8&n.f)&&Ve(n))try{n.c()}catch(n){t||(e=n,t=!0)}n=r}}if(Re=0,P--,t)throw e}}function Pe(e){if(P>0)return e();P++;try{return e()}finally{Ne()}}var N=void 0;function Fe(e){var t=N;N=void 0;try{return e()}finally{N=t}}var Ie,Le=void 0,P=0,Re=0,ze=0;function Be(e){if(N!==void 0){var t=e.n;if(t===void 0||t.t!==N)return t={i:0,S:e,p:N.s,n:void 0,t:N,e:void 0,x:void 0,r:t},N.s!==void 0&&(N.s.n=t),N.s=t,e.n=t,32&N.f&&e.S(t),t;if(t.i===-1)return t.i=0,t.n!==void 0&&(t.n.p=t.p,t.p!==void 0&&(t.p.n=t.n),t.p=N.s,t.n=void 0,N.s.n=t,N.s=t),t}}function F(e,t){this.v=e,this.i=0,this.n=void 0,this.t=void 0,this.W=t?.watched,this.Z=t?.unwatched,this.name=t?.name}F.prototype.brand=Me,F.prototype.h=function(){return!0},F.prototype.S=function(e){var t=this,n=this.t;n!==e&&e.e===void 0&&(e.x=n,this.t=e,n===void 0?Fe(function(){var e;(e=t.W)==null||e.call(t)}):n.e=e)},F.prototype.U=function(e){var t=this;if(this.t!==void 0){var n=e.e,r=e.x;n!==void 0&&(n.x=r,e.e=void 0),r!==void 0&&(r.e=n,e.x=void 0),e===this.t&&(this.t=r,r===void 0&&Fe(function(){var e;(e=t.Z)==null||e.call(t)}))}},F.prototype.subscribe=function(e){var t=this;return Je(function(){var n=t.value,r=N;N=void 0;try{e(n)}finally{N=r}},{name:`sub`})},F.prototype.valueOf=function(){return this.value},F.prototype.toString=function(){return this.value+``},F.prototype.toJSON=function(){return this.value},F.prototype.peek=function(){var e=N;N=void 0;try{return this.value}finally{N=e}},Object.defineProperty(F.prototype,`value`,{get:function(){var e=Be(this);return e!==void 0&&(e.i=this.i),this.v},set:function(e){if(e!==this.v){if(Re>100)throw Error(`Cycle detected`);this.v=e,this.i++,ze++,P++;try{for(var t=this.t;t!==void 0;t=t.x)t.t.N()}finally{Ne()}}}});function I(e,t){return new F(e,t)}function Ve(e){for(var t=e.s;t!==void 0;t=t.n)if(t.S.i!==t.i||!t.S.h()||t.S.i!==t.i)return!0;return!1}function He(e){for(var t=e.s;t!==void 0;t=t.n){var n=t.S.n;if(n!==void 0&&(t.r=n),t.S.n=t,t.i=-1,t.n===void 0){e.s=t;break}}}function Ue(e){for(var t=e.s,n=void 0;t!==void 0;){var r=t.p;t.i===-1?(t.S.U(t),r!==void 0&&(r.n=t.n),t.n!==void 0&&(t.n.p=r)):n=t,t.S.n=t.r,t.r!==void 0&&(t.r=void 0),t=r}e.s=n}function L(e,t){F.call(this,void 0),this.x=e,this.s=void 0,this.g=ze-1,this.f=4,this.W=t?.watched,this.Z=t?.unwatched,this.name=t?.name}L.prototype=new F,L.prototype.h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===ze))return!0;if(this.g=ze,this.f|=1,this.i>0&&!Ve(this))return this.f&=-2,!0;var e=N;try{He(this),N=this;var t=this.x();(16&this.f||this.v!==t||this.i===0)&&(this.v=t,this.f&=-17,this.i++)}catch(e){this.v=e,this.f|=16,this.i++}return N=e,Ue(this),this.f&=-2,!0},L.prototype.S=function(e){if(this.t===void 0){this.f|=36;for(var t=this.s;t!==void 0;t=t.n)t.S.S(t)}F.prototype.S.call(this,e)},L.prototype.U=function(e){if(this.t!==void 0&&(F.prototype.U.call(this,e),this.t===void 0)){this.f&=-33;for(var t=this.s;t!==void 0;t=t.n)t.S.U(t)}},L.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var e=this.t;e!==void 0;e=e.x)e.t.N()}},Object.defineProperty(L.prototype,`value`,{get:function(){if(1&this.f)throw Error(`Cycle detected`);var e=Be(this);if(this.h(),e!==void 0&&(e.i=this.i),16&this.f)throw this.v;return this.v}});function We(e,t){return new L(e,t)}function Ge(e){var t=e.u;if(e.u=void 0,typeof t==`function`){P++;var n=N;N=void 0;try{t()}catch(t){throw e.f&=-2,e.f|=8,Ke(e),t}finally{N=n,Ne()}}}function Ke(e){for(var t=e.s;t!==void 0;t=t.n)t.S.U(t);e.x=void 0,e.s=void 0,Ge(e)}function qe(e){if(N!==this)throw Error(`Out-of-order effect`);Ue(this),N=e,this.f&=-2,8&this.f&&Ke(this),Ne()}function R(e,t){this.x=e,this.u=void 0,this.s=void 0,this.o=void 0,this.f=32,this.name=t?.name,Ie&&Ie.push(this)}R.prototype.c=function(){var e=this.S();try{if(8&this.f||this.x===void 0)return;var t=this.x();typeof t==`function`&&(this.u=t)}finally{e()}},R.prototype.S=function(){if(1&this.f)throw Error(`Cycle detected`);this.f|=1,this.f&=-9,Ge(this),He(this),P++;var e=N;return N=this,qe.bind(this,e)},R.prototype.N=function(){2&this.f||(this.f|=2,this.o=Le,Le=this)},R.prototype.d=function(){this.f|=8,1&this.f||Ke(this)},R.prototype.dispose=function(){this.d()};function Je(e,t){var n=new R(e,t);try{n.c()}catch(e){throw n.d(),e}var r=n.d.bind(n);return r[Symbol.dispose]=r,r}var Ye,Xe,Ze,Qe=typeof window<`u`&&!!window.__PREACT_SIGNALS_DEVTOOLS__,$e=[],et=[];Je(function(){Ye=this.N})();function z(e,n){t[e]=n.bind(null,t[e]||function(){})}function tt(e){Ze&&Ze(),Ze=e&&e.S()}function nt(e){var t=this,n=e.data,i=it(n);i.value=n;var a=Te(function(){for(var e=t,n=t.__v;n=n.__;)if(n.__c){n.__c.__$f|=4;break}var a=We(function(){var e=i.value.value;return e===0?0:!0===e?``:e||``}),o=We(function(){return!Array.isArray(a.value)&&!r(a.value)}),s=Je(function(){if(this.N=ct,o.value){var t=a.value;e.__v&&e.__v.__e&&e.__v.__e.nodeType===3&&(e.__v.__e.data=t)}}),c=t.__$u.d;return t.__$u.d=function(){s(),c.call(this)},[o,a]},[]),o=a[0],s=a[1];return o.value?s.peek():s.value}nt.displayName=`ReactiveTextNode`,Object.defineProperties(F.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:nt},props:{configurable:!0,get:function(){return{data:this}}},__b:{configurable:!0,value:1}}),z(`__b`,function(e,t){if(typeof t.type==`string`){var n,r=t.props;for(var i in r)if(i!==`children`){var a=r[i];a instanceof F&&(n||(t.__np=n={}),n[i]=a,r[i]=a.peek())}}e(t)}),z(`__r`,function(e,t){if(t.type!==x){tt();var n,r=t.__c;r&&(r.__$f&=-2,(n=r.__$u)===void 0&&(r.__$u=n=function(e,t){var n;return Je(function(){n=this},{name:t}),n.c=e,n}(function(){var e;Qe&&((e=n.y)==null||e.call(n)),r.__$f|=1,r.setState({})},typeof t.type==`function`?t.type.displayName||t.type.name:``))),Xe=r,tt(n)}e(t)}),z(`__e`,function(e,t,n,r){tt(),Xe=void 0,e(t,n,r)}),z(`diffed`,function(e,t){tt(),Xe=void 0;var n;if(typeof t.type==`string`&&(n=t.__e)){var r=t.__np,i=t.props;if(r){var a=n.U;if(a)for(var o in a){var s=a[o];s!==void 0&&!(o in r)&&(s.d(),a[o]=void 0)}else a={},n.U=a;for(var c in r){var l=a[c],u=r[c];l===void 0?(l=rt(n,c,u,i),a[c]=l):l.o(u,i)}}}e(t)});function rt(e,t,n,r){var i=t in e&&e.ownerSVGElement===void 0,a=I(n);return{o:function(e,t){a.value=e,r=t},d:Je(function(){this.N=ct;var n=a.value.value;r[t]!==n&&(r[t]=n,i?e[t]=n:n!=null&&(!1!==n||t[4]===`-`)?e.setAttribute(t,n):e.removeAttribute(t))})}}z(`unmount`,function(e,t){if(typeof t.type==`string`){var n=t.__e;if(n){var r=n.U;if(r)for(var i in n.U=void 0,r){var a=r[i];a&&a.d()}}}else{var o=t.__c;if(o){var s=o.__$u;s&&(o.__$u=void 0,s.d())}}e(t)}),z(`__h`,function(e,t,n,r){(r<3||r===9)&&(t.__$f|=2),e(t,n,r)}),S.prototype.shouldComponentUpdate=function(e,t){if(this.__R)return!0;var n=this.__$u,r=n&&n.s!==void 0;for(var i in t)return!0;if(this.__f||typeof this.u==`boolean`&&!0===this.u){var a=2&this.__$f;if(!(r||a||4&this.__$f)||1&this.__$f)return!0}else if(!(r||4&this.__$f)||3&this.__$f)return!0;for(var o in e)if(o!==`__source`&&e[o]!==this.props[o])return!0;for(var s in this.props)if(!(s in e))return!0;return!1};function it(e,t){return Te(function(){return I(e,t)},[])}var at=typeof requestAnimationFrame>`u`?setTimeout:function(e){var t=function(){clearTimeout(n),cancelAnimationFrame(r),e()},n=setTimeout(t,35),r=requestAnimationFrame(t)},ot=function(e){queueMicrotask(function(){queueMicrotask(e)})};function st(){Pe(function(){for(var e;e=et.shift();)Ye.call(e)})}function ct(){et.push(this)===1&&(t.requestAnimationFrame||ot)(st)}const B={ANALYZE_REQUEST:`TESTUDO_ANALYZE_REQUEST`,ANALYZE_RESULT:`TESTUDO_ANALYSIS_RESULT`,CHECK_ADDRESS:`TESTUDO_CHECK_ADDRESS`,ADDRESS_CHECK_RESULT:`TESTUDO_ADDRESS_CHECK_RESULT`,RESOLVE_TOKEN:`TESTUDO_RESOLVE_TOKEN`,TOKEN_RESULT:`TESTUDO_TOKEN_RESULT`,GET_SETTINGS:`TESTUDO_GET_SETTINGS`,SETTINGS_RESULT:`TESTUDO_SETTINGS_RESULT`,RECORD_BLOCKED:`TESTUDO_RECORD_BLOCKED`};function lt(e){if(!e)throw Error(`[Testudo] Channel nonce is empty — aborting to prevent insecure channel`);let t=`testudo-req-${e}`,n=`testudo-res-${e}`;return{sendRequest(e){document.dispatchEvent(new CustomEvent(t,{detail:e,bubbles:!1,cancelable:!1}))},sendResponse(e){document.dispatchEvent(new CustomEvent(n,{detail:e,bubbles:!1,cancelable:!1}))},onRequest(e){let n=t=>e(t.detail);return document.addEventListener(t,n),()=>document.removeEventListener(t,n)},onResponse(e){let t=t=>e(t.detail);return document.addEventListener(n,t),()=>document.removeEventListener(n,t)}}}function ut(){let e=crypto.randomUUID(),t=``,n=e=>{t=e.detail};if(document.addEventListener(`testudo-hs-${e}`,n,{once:!0}),document.dispatchEvent(new CustomEvent(`testudo-handshake`,{detail:e,bubbles:!1,cancelable:!1})),document.removeEventListener(`testudo-hs-${e}`,n),t)return t;let r=document.querySelector(`script[data-testudo-nonce]`),i=r?.dataset.testudoNonce??``;return r&&delete r.dataset.testudoNonce,i}const dt=lt(ut());function ft(e,t,n,r=1e4){return new Promise((i,a)=>{let o=crypto.randomUUID(),s=dt.onResponse(e=>{e.type===t&&e.requestId===o&&(s(),clearTimeout(c),i(e.result))});dt.sendRequest({type:e,requestId:o,...n});let c=setTimeout(()=>{s(),a(Error(`${e} timeout`))},r)})}function pt(e,t){return ft(B.CHECK_ADDRESS,B.ADDRESS_CHECK_RESULT,{address:e,chainId:t})}async function mt(e,t){let n=new Map;for(let t of e){let e=t.address.toLowerCase();n.has(e)||n.set(e,[]),n.get(e)?.push(t)}let r=new Map,i=[],a=Array.from(n.entries()).map(async([e,n])=>{try{let a=await pt(e,t);r.set(e,a),(a.risk===`CRITICAL`||a.risk===`HIGH`)&&i.push(...n)}catch{}});return await Promise.all(a),{malicious:i,results:r}}function ht(e,t){return ft(B.ANALYZE_REQUEST,B.ANALYZE_RESULT,{delegateAddress:e,chainId:t})}function gt(){dt.sendRequest({type:B.RECORD_BLOCKED,requestId:crypto.randomUUID()})}function _t(e){return ft(B.RESOLVE_TOKEN,B.TOKEN_RESULT,{address:e},3e3).catch(()=>({name:null,symbol:null,decimals:null}))}const vt={visible:!1,loading:!1,analysis:null,context:`delegation`,resolver:null},V=I(vt),H=I(``),yt=We(()=>H.value.trim().toUpperCase()===`I ACCEPT THE RISK`),bt=I(`content_copy`);let xt=0;function St(){return xt}function Ct(e){let t=V.value.resolver;return t&&t(!1),++xt,new Promise(t=>{H.value=``,bt.value=`content_copy`,V.value={visible:!0,loading:!1,analysis:e.analysis,context:e.context??`delegation`,permitInfo:e.permitInfo,approvalInfo:e.approvalInfo,nftApprovalInfo:e.nftApprovalInfo,blindSignatureInfo:e.blindSignatureInfo,typedDataScanInfo:e.typedDataScanInfo,intent:e.intent,resolver:t}})}function wt(e){let t=V.value.resolver;return t&&t(!1),new Promise(t=>{H.value=``,bt.value=`content_copy`,V.value={visible:!0,loading:!0,analysis:{address:e.address,risk:`UNKNOWN`,threats:[],blocked:!1},context:e.context,resolver:t}})}function Tt(e,t,n){let r=V.value;!r.visible||!r.resolver||(V.value={...r,loading:!1,analysis:e,intent:t,context:n??r.context})}function Et(e,t){let n=V.value;!n.visible||!n.resolver||t!==xt||(V.value={...n,intent:e})}function Dt(){let{resolver:e}=V.value;e&&(V.value=vt,H.value=``,e(!0))}function Ot(e){let{resolver:t}=V.value;V.value=vt,H.value=``,t&&t(e)}function kt(){V.value.loading||gt(),Ot(!1)}function At(){Ot(!0)}function jt(){yt.value&&Ot(!0)}async function Mt(){let e=V.value.analysis?.address;if(e)try{await navigator.clipboard.writeText(e),bt.value=`check`,setTimeout(()=>{bt.value=`content_copy`},2e3)}catch{console.error(`[Testudo] Failed to copy address`)}}const U=I({visible:!1,title:``,text:``});let Nt;function Pt(e){let t=e.warnings?.find(e=>e.severity!==`INFO`);U.value={visible:!0,title:t?.title||`Review Required`,text:t?.description||`Review this delegation carefully`},Nt&&clearTimeout(Nt),Nt=setTimeout(()=>{U.value={...U.value,visible:!1}},7e3)}function Ft(){Nt&&clearTimeout(Nt),U.value={...U.value,visible:!1}}const W=I({visible:!1,address:``});let It;function Lt(e){W.value={visible:!0,address:e.address},It&&clearTimeout(It),It=setTimeout(()=>{W.value={...W.value,visible:!1}},5e3)}function Rt(){It&&clearTimeout(It),W.value={...W.value,visible:!1}}var zt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,Bt=0,Vt=Array.isArray;function G(e,n,r,i,a,o){n||={};var s,c,l=n;if(`ref`in l)for(c in l={},n)c==`ref`?s=n[c]:l[c]=n[c];var u={type:e,props:l,key:r,ref:s,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--Bt,__i:-1,__u:0,__source:a,__self:o};if(typeof e==`function`&&(s=e.defaultProps))for(c in s)l[c]===void 0&&(l[c]=s[c]);return t.vnode&&t.vnode(u),u}function Ht(){let{visible:e,title:t,text:n}=U.value;return e?G(`div`,{class:`testudo-toast`,id:`testudo-info-toast`,children:[G(`span`,{class:`testudo-toast-icon`,children:`info`}),G(`div`,{class:`testudo-toast-content`,children:[G(`div`,{class:`testudo-toast-title`,children:[G(`span`,{class:`testudo-toast-icon-inline`,children:`bolt`}),t]}),G(`div`,{class:`testudo-toast-text`,children:n}),G(`button`,{type:`button`,class:`testudo-toast-dismiss`,id:`testudo-toast-dismiss`,onClick:Ft,children:`Dismiss`})]})]}):null}function K(e,t=10,n=6){return e.length<=t+n?e:`${e.slice(0,t)}...${e.slice(-n)}`}function Ut(){let{visible:e,address:t}=W.value;return e?G(`div`,{class:`testudo-toast-unknown`,id:`testudo-unknown-toast`,children:[G(`span`,{class:`testudo-toast-unknown-icon`,children:`help_outline`}),G(`div`,{class:`testudo-toast-unknown-content`,children:[G(`div`,{class:`testudo-toast-unknown-title`,children:`Unverified Contract`}),G(`div`,{class:`testudo-toast-unknown-text`,children:`This contract has no bytecode or doesn't exist on-chain. It may be an EOA (regular wallet) or undeployed contract.`}),G(`div`,{class:`testudo-toast-unknown-address`,children:K(t)}),G(`button`,{type:`button`,class:`testudo-toast-unknown-dismiss`,id:`testudo-unknown-dismiss`,onClick:Rt,children:`Dismiss`})]})]}):null}function Wt(e){switch(e){case`eth-sign-danger`:case`blind-signature`:return`Signer Address`;case`typed-data-scan`:return`Malicious Address`;case`nft-approval`:return`Operator Address`;case`approval`:case`permit`:return`Spender Address`;case`transaction`:return`Recipient Address`;default:return`Target Contract`}}function Gt({address:e,context:t,copyIcon:n,onCopy:r}){return G(`div`,{class:`testudo-address-section`,children:G(`div`,{class:`testudo-address-box`,children:[G(`span`,{class:`testudo-address-label`,children:Wt(t)}),G(`div`,{class:`testudo-address-value`,children:[G(`span`,{class:`testudo-address-text`,children:K(e)}),G(`button`,{type:`button`,class:`testudo-copy-btn`,id:`testudo-copy`,title:`Copy Address`,onClick:r,children:G(`span`,{class:`testudo-material-icon`,children:n})})]})]})})}function Kt({analysis:e}){let t=e.warnings?.find(e=>e.severity===`CRITICAL`||e.severity===`HIGH`)||e.warnings?.find(e=>e.severity===`MEDIUM`),n=e.risk===`CRITICAL`?`Fund Drain Detected`:`Multiple Risk Factors Detected`,r=e.risk===`CRITICAL`?`This contract contains logic known to drain wallets immediately upon signature.`:`This contract has multiple concerning patterns that warrant caution.`,i=t?.title||n,a=t?.description||r,o=e.risk===`MEDIUM`;return G(`div`,{class:`testudo-alert${o?` testudo-alert-medium`:``}`,children:[G(`div`,{class:`testudo-alert-header`,children:[G(`span`,{class:`testudo-material-icon`,children:o?`info`:`error`}),G(`span`,{class:`testudo-alert-title`,children:[e.risk,`: `,i]})]}),G(`p`,{class:`testudo-alert-description`,children:a})]})}const qt={approve:`0x095ea7b3`,increaseAllowance:`0x39509351`,decreaseAllowance:`0xa457c2d7`},Jt={setApprovalForAll:`0xa22cb465`},Yt={"0x1e0049783f008a0085193e00003d00cd54003c71":`OpenSea Seaport 1.1`,"0x00000000000001ad428e4906ae43d8f9852d0dd6":`OpenSea Seaport 1.4`,"0x00000000000000adc04c56bf30ac9d3c0aaf14dc":`OpenSea Seaport 1.5`,"0x00000000000000adc04c56bf30ac9d3c0aaf14dd":`OpenSea Seaport 1.6`,"0x000000000000ad05ccc4f10045630fb830b95127":`Blur`,"0x59728544b08ab483533076417fbbb2fd0b17ce3a":`LooksRare Exchange`,"0x74312363e45dcaba76c59ec49a7aa8a65a67eed3":`X2Y2 Exchange`,"0x2b2e8cda09bba9660dca5cb6233787738ad68329":`Sudoswap`},Xt=`0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff`,Zt=`0xffffffffffffffffffffffffffffffffffffffff`;function Qt(e){if(!e||e.length<10)return!1;let t=e.slice(0,10).toLowerCase();return Object.values(qt).includes(t)}function $t(e,t){let n=e.slice(0,10).toLowerCase();if(e.length<138)return null;let r=e.slice(10,74),i=e.slice(74,138),a=`0x${r.slice(24).toLowerCase()}`;if(!/^0x[a-fA-F0-9]{40}$/.test(a))return null;let o=n===qt.approve?`approve`:n===qt.increaseAllowance?`increaseAllowance`:`decreaseAllowance`;return{type:o,spender:a,amount:`0x${i}`,tokenAddress:t.toLowerCase()}}function q(e){if(!e)return!1;let t=e.toLowerCase();if(t===Xt||t===Zt||t===`unlimited`)return!0;if(/[eE]/.test(e)){let t=Number(e);if(!Number.isNaN(t)&&t>1e30)return!0}try{return BigInt(e)>BigInt(10)**BigInt(30)}catch{return!1}}function en(e){if(q(e))return`UNLIMITED`;try{let t=BigInt(e);return t.toLocaleString()}catch{return`Invalid Amount Data`}}function tn(e){try{return BigInt(e)===BigInt(0)}catch{return!1}}function nn(e){if(!e||e.length<10)return!1;let t=e.slice(0,10).toLowerCase();return t===Jt.setApprovalForAll}function rn(e,t){if(e.length<138)return null;let n=e.slice(10,74),r=e.slice(74,138),i=`0x${n.slice(24).toLowerCase()}`;if(!/^0x[a-fA-F0-9]{40}$/.test(i))return null;let a=BigInt(`0x${r}`)!==BigInt(0);return{type:`setApprovalForAll`,operator:i,approved:a,collectionAddress:t.toLowerCase()}}function an(e){return Yt[e.toLowerCase()]||null}function J({label:e,value:t,style:n,mb:r=!0}){return G(`div`,{class:`testudo-address-box`,style:r?`margin-bottom:6px`:void 0,children:[G(`span`,{class:`testudo-address-label`,children:e}),G(`span`,{class:`testudo-address-text`,style:n,children:t})]})}function on(e){switch(e){case`danger`:return`color:var(--danger);font-weight:700`;case`warning`:return`color:var(--warn);font-weight:600`;default:return}}function sn({intent:e}){return G(`div`,{class:`testudo-address-section`,children:[G(`div`,{class:`testudo-intent-action`,children:e.action}),e.details.map((t,n)=>G(J,{label:t.label,value:t.value,style:t.mono?`font-family:var(--font-mono);font-size:12px;${on(t.emphasis)??``}`:on(t.emphasis),mb:n<e.details.length-1},t.label)),e.chainName&&G(J,{label:`Network`,value:e.chainName,mb:!1})]})}function cn({permitInfo:e,approvalInfo:t,nftApprovalInfo:n,blindSignatureInfo:r,typedDataScanInfo:i,intent:a}){return a?G(sn,{intent:a}):G(x,{children:[e&&G(`div`,{class:`testudo-address-section`,children:[e.tokenName&&G(J,{label:`Token`,value:`${e.tokenName}${e.token?` (${e.token.slice(0,8)}...)`:``}`}),G(J,{label:`Amount`,value:q(e.value)?`UNLIMITED`:e.value===`batch`?`Batch (multiple tokens)`:e.value||`Unknown`,style:q(e.value)?`color:var(--danger);font-weight:700`:void 0}),e.deadline&&G(J,{label:`Deadline`,value:String(e.deadline),mb:!1})]}),t&&G(`div`,{class:`testudo-address-section`,children:[G(J,{label:`Token Contract`,value:K(t.tokenAddress)}),G(J,{label:`Amount`,value:en(t.amount),style:q(t.amount)?`color:var(--danger);font-weight:700`:void 0}),G(J,{label:`Operation`,value:t.type===`approve`?`approve()`:t.type===`increaseAllowance`?`increaseAllowance()`:`decreaseAllowance()`,mb:!1})]}),n&&G(`div`,{class:`testudo-address-section`,children:[G(J,{label:`Collection`,value:K(n.collectionAddress)}),G(J,{label:`Access Level`,value:`FULL COLLECTION`,style:`color:var(--danger);font-weight:700`,mb:!1})]}),r&&G(`div`,{class:`testudo-address-section`,children:[G(J,{label:`Method`,value:r.type}),G(J,{label:`Message${r.isHex?` (hex)`:``}`,value:r.messagePreview,style:`font-family:var(--font-mono);font-size:12px;word-break:break-all`,mb:!1})]}),i&&G(`div`,{class:`testudo-address-section`,children:[G(J,{label:`Primary Type`,value:i.primaryType}),i.domainName&&G(J,{label:`Domain`,value:i.domainName}),i.maliciousAddresses.slice(0,3).map(e=>G(J,{label:`Found in: ${e.fieldPath}`,value:K(e.address),style:`color:var(--danger)`},e.address))]})]})}function ln(e){switch(e){case`delegation`:return`Checking delegation contract for threats...`;case`approval`:return`Checking spender address...`;case`permit`:return`Checking permit spender...`;case`transaction`:return`Checking recipient address...`;case`nft-approval`:return`Checking operator address...`;default:return`Running security analysis...`}}function un(e){return e.length<=13?e:`${e.slice(0,6)}...${e.slice(-4)}`}function dn({context:e,address:t}){return G(`div`,{id:`testudo-warning-overlay`,children:G(`div`,{class:`testudo-modal`,children:[G(`div`,{class:`testudo-header`,children:[G(`div`,{class:`testudo-header-icon testudo-loading-icon`,children:G(`span`,{class:`testudo-material-icon testudo-spin`,children:`shield`})}),G(`div`,{class:`testudo-header-text`,children:[G(`h2`,{class:`testudo-title`,children:`Analyzing Contract`}),G(`p`,{class:`testudo-subtitle`,children:ln(e)})]})]}),G(`div`,{class:`testudo-address-section`,children:G(`div`,{class:`testudo-address-box`,children:[G(`span`,{class:`testudo-address-label`,children:`Contract`}),G(`div`,{class:`testudo-address-value`,children:G(`span`,{class:`testudo-address-text`,children:un(t)})})]})}),G(`div`,{class:`testudo-loading-bar-container`,children:G(`div`,{class:`testudo-loading-bar`})}),G(`div`,{class:`testudo-buttons`,children:G(`button`,{type:`button`,class:`testudo-btn-cancel`,disabled:!0,style:{opacity:.5,cursor:`wait`},children:[G(`span`,{class:`testudo-material-icon`,children:`hourglass_top`}),`Analyzing...`]})})]})})}function fn({confirmInput:e,isConfirmValid:t,onInput:n,onProceed:r}){return G(`div`,{class:`testudo-confirm-section`,children:[G(`label`,{class:`testudo-confirm-label`,for:`testudo-confirm-input`,children:[`Type `,G(`strong`,{class:`testudo-text-danger`,children:`I ACCEPT THE RISK`}),` to proceed`]}),G(`input`,{type:`text`,class:`testudo-confirm-input`,id:`testudo-confirm-input`,placeholder:`I ACCEPT THE RISK`,autocomplete:`off`,spellcheck:!1,value:e.value,onInput:e=>n(e.target.value)}),G(`button`,{type:`button`,class:`testudo-btn-danger-confirm${t.value?` enabled`:``}`,id:`testudo-eth-sign-proceed`,disabled:!t.value,onClick:r,children:[G(`span`,{class:`testudo-material-icon`,children:`warning`}),`Proceed with eth_sign`]})]})}function pn({context:e,confirmInput:t,isConfirmValid:n,onCancel:r,onProceed:i,onEthSignProceed:a,onConfirmInput:o}){return G(`div`,{class:`testudo-buttons`,children:[G(`button`,{type:`button`,class:`testudo-btn-cancel`,id:`testudo-cancel`,onClick:r,children:[G(`span`,{class:`testudo-material-icon`,children:`shield`}),`Cancel (Safe)`]}),e===`eth-sign-danger`||e===`replay-risk`?G(fn,{confirmInput:t,isConfirmValid:n,onInput:o,onProceed:a}):G(`div`,{class:`testudo-secondary-actions`,children:G(`button`,{type:`button`,class:`testudo-btn-danger`,id:`testudo-proceed`,onClick:i,children:[G(`span`,{children:`Proceed Anyway`}),G(`span`,{class:`testudo-material-icon`,children:`arrow_forward`})]})})]})}function mn(e){switch(e){case`eth-sign-danger`:return`Dangerous: eth_sign Detected`;case`blind-signature`:return`Blind Signature Request`;case`typed-data-scan`:return`Malicious Address in Signed Data`;case`nft-approval`:return`NFT Collection Approval Detected`;case`approval`:return`Token Approval Detected`;case`permit`:return`Permit Signature Detected`;case`transaction`:return`Malicious Recipient Detected`;default:return`Dangerous Contract Detected`}}function hn(e){return e===`HIGH`?`Suspicious Message Detected`:`Blind Signature Request`}function gn({context:e,analysis:t,intent:n}){let r=n?.headline??(e===`blind-signature`?hn(t.risk):mn(e));return G(`div`,{class:`testudo-header`,children:[G(`div`,{class:`testudo-header-icon`,children:G(`span`,{class:`testudo-material-icon`,children:`gpp_maybe`})}),G(`div`,{class:`testudo-header-text`,children:[G(`h2`,{class:`testudo-title`,children:r}),G(`p`,{class:`testudo-subtitle`,children:_n(e,t)})]})]})}function _n(e,t){switch(e){case`eth-sign-danger`:return G(x,{children:[G(`strong`,{children:`eth_sign`}),` is deprecated and signs raw hashes. An attacker can craft a valid `,G(`strong`,{children:`transaction hash`}),` — signing it gives them full control of your wallet.`]});case`blind-signature`:return t.risk===`HIGH`?G(x,{children:[`This message contains `,G(`strong`,{children:`phishing patterns`}),` commonly used in scams.`]}):G(x,{children:[`You are signing `,G(`strong`,{children:`arbitrary data`}),` that cannot be verified.`]});case`typed-data-scan`:return G(x,{children:[`A `,G(`strong`,{children:`known malicious address`}),` was found in the data you are about to sign.`]});case`nft-approval`:return G(x,{children:[`You are granting `,G(`strong`,{children:`full collection access`}),` to another address.`]});case`approval`:return G(x,{children:[`You are granting `,G(`strong`,{children:`token spending rights`}),` to another address.`]});case`permit`:return G(x,{children:[`This signature grants `,G(`strong`,{children:`token spending rights`}),`!`]});case`transaction`:return G(x,{children:[`You are about to send funds to a `,G(`strong`,{children:`known scammer`}),` address.`]});default:return G(x,{children:[`We have intercepted a malicious `,G(`strong`,{children:`EIP-7702`}),` delegation request.`]})}}const vn={auto_forwarder:{icon:`currency_exchange`,shortDesc:`Redirects incoming assets to external address`,format:`Auto-forwards ETH`},delegate_call:{icon:`call_split`,shortDesc:`Executes code in context of your wallet`,format:`Uses DELEGATECALL`},self_destruct:{icon:`delete_forever`,shortDesc:`Can destroy itself after draining funds`,format:`Can self-destruct`},unlimited_approval:{icon:`all_inclusive`,shortDesc:`Requests access to all your tokens`,format:`Unlimited token approval`},create2:{icon:`add_box`,shortDesc:`Can deploy contracts at predictable addresses`,format:`Uses CREATE2`},metamorphic:{icon:`swap_horiz`,shortDesc:`Code can change while keeping same address`,format:`Metamorphic contract`},chainid_branching:{icon:`public`,shortDesc:`Behavior changes based on network`,format:`Cross-chain behavior`},chainid_comparison:{icon:`public`,shortDesc:`May restrict behavior on specific chains`,format:`Network ID comparison`},chainid_read:{icon:`public`,shortDesc:`Reads network ID for conditional logic`,format:`Reads network ID`},token_drain_fallback:{icon:`token`,shortDesc:`Auto-drains tokens on any interaction`,format:`Token drain in fallback`},token_hardcoded_dest:{icon:`token`,shortDesc:`Sends funds to hardcoded attacker address`,format:`Hardcoded destination`},token_no_auth:{icon:`token`,shortDesc:`No signature verification for transfers`,format:`No access control`},token_replay_risk:{icon:`replay`,shortDesc:`Same signature can be reused multiple times`,format:`Replay attack risk`},eip7702_replay_risk:{icon:`replay`,shortDesc:`Valid on ALL chains — signature can be replayed on any network`,format:`Cross-chain replay risk`},token_approval_no_auth:{icon:`token`,shortDesc:`Unlimited access without verification`,format:`Unprotected approvals`},token_with_auth:{icon:`token`,shortDesc:`Has some security controls in place`,format:`Token transfers enabled`},nft_full_collection_access:{icon:`collections`,shortDesc:`Grants control over ALL NFTs in this collection`,format:`Full NFT collection access`},eth_sign_deprecated:{icon:`dangerous`,shortDesc:`eth_sign is deprecated and signs raw hashes without safety prefix`,format:`Deprecated: eth_sign`},blind_signature:{icon:`visibility_off`,shortDesc:`Signing arbitrary data without visibility into its purpose`,format:`Blind signature`},airdrop_scam:{icon:`card_giftcard`,shortDesc:`Message contains airdrop/reward scam language`,format:`Airdrop scam pattern`},verification_scam:{icon:`verified_user`,shortDesc:`Message impersonates wallet verification request`,format:`Verification scam pattern`},urgency:{icon:`timer`,shortDesc:`Message uses urgency pressure tactics`,format:`Urgency pressure tactic`},impersonation:{icon:`person_alert`,shortDesc:`Message impersonates a known brand or protocol`,format:`Brand impersonation`},financial_lure:{icon:`payments`,shortDesc:`Message contains financial lure language`,format:`Financial lure`},typed_data_malicious_address:{icon:`gpp_bad`,shortDesc:`A known malicious address is embedded in the signed data`,format:`Malicious address in signed data`},deployer_fresh:{icon:`new_releases`,shortDesc:`Deployed by a brand-new account with almost no history`,format:`Fresh deployer account`},deployer_low_nonce:{icon:`person_alert`,shortDesc:`Deployer account has very few transactions`,format:`Low-activity deployer`},deployer_new_contract:{icon:`schedule`,shortDesc:`Contract was deployed very recently`,format:`Recently deployed`},ETH_AUTO_FORWARDER:{icon:`currency_exchange`,shortDesc:`Known malicious ETH drainer contract`,format:`Known ETH drainer`},INFERNO_DRAINER:{icon:`local_fire_department`,shortDesc:`Known Inferno Drainer attack contract`,format:`Inferno Drainer`}};function yn(e){return vn[e]?.icon||`warning`}function bn(e){return vn[e]?.shortDesc||`Suspicious behavior detected`}function xn(e){return vn[e]?.format||e.replace(/_/g,` `)}function Sn({threats:e}){return G(`div`,{class:`testudo-threats`,children:[G(`h3`,{class:`testudo-threats-title`,children:`Threats Detected`}),e.slice(0,3).map(e=>G(`div`,{class:`testudo-threat-item`,children:[G(`div`,{class:`testudo-threat-icon`,children:G(`span`,{class:`testudo-material-icon`,children:yn(e)})}),G(`div`,{class:`testudo-threat-content`,children:[G(`span`,{class:`testudo-threat-name`,children:xn(e)}),G(`span`,{class:`testudo-threat-desc`,children:bn(e)})]})]},e))]})}function Cn(){let{visible:e,loading:t,analysis:n,context:r,permitInfo:i,approvalInfo:a,nftApprovalInfo:o,blindSignatureInfo:s,typedDataScanInfo:c,intent:l}=V.value;return we(()=>{if(!e)return;let t=e=>{e.key===`Escape`&&kt()};return document.addEventListener(`keydown`,t),()=>document.removeEventListener(`keydown`,t)},[e]),e?t&&n?G(dn,{context:r,address:n.address}):n?G(`div`,{id:`testudo-warning-overlay`,children:G(`div`,{class:`testudo-modal`,children:[G(gn,{context:r,analysis:n,intent:l}),G(Kt,{analysis:n}),G(cn,{permitInfo:i,approvalInfo:a,nftApprovalInfo:o,blindSignatureInfo:s,typedDataScanInfo:c,intent:l}),G(Sn,{threats:n.threats}),G(Gt,{address:n.address,context:r,copyIcon:bt,onCopy:Mt}),G(pn,{context:r,confirmInput:H,isConfirmValid:yt,onCancel:kt,onProceed:At,onEthSignProceed:jt,onConfirmInput:e=>{H.value=e}})]})}):null:null}const wn=`
:host {
  all: initial;
  display: block !important;
  position: static !important;
  visibility: visible !important;
}

/* ── Design Tokens — Quiet Confidence ── */
#testudo-warning-overlay {
  --surface: #141416;
  --surface-raised: #1c1c1f;
  --border-strong: rgba(255, 255, 255, 0.14);
  --border-subtle: rgba(255, 255, 255, 0.08);

  --text: #fafafa;
  --text-secondary: #e5e5e7;
  --text-muted: #a0a0a8;
  --text-dim: #5a5a60;

  --brand: #1a9b8c;
  --brand-hover: #26b5a4;
  --brand-ink: #03150f;

  --danger: #dc2626;
  --danger-bg: rgba(220, 38, 38, 0.1);
  --danger-border: rgba(220, 38, 38, 0.3);

  --warn: #f59e0b;
  --warn-bg: rgba(245, 158, 11, 0.1);

  --font-sans: 'Geist', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
  --font-mono: 'Geist Mono', ui-monospace, monospace;
}

@keyframes testudo-fade-in {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes testudo-modal-in {
  from { opacity: 0; transform: translateY(8px) scale(0.98); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

@keyframes testudo-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes testudo-slide-in {
  from { transform: translateX(120%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}

@keyframes testudo-loading-slide {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

#testudo-warning-overlay *,
#testudo-warning-overlay *::before,
#testudo-warning-overlay *::after {
  box-sizing: border-box;
}

#testudo-warning-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(10, 10, 11, 0.85);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999999;
  font-family: var(--font-sans);
  animation: testudo-fade-in 0.25s ease;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: var(--text-secondary);
}

/* ── Modal Shell ── */

.testudo-modal {
  background: var(--surface);
  border-radius: 14px;
  border: 1px solid var(--border-strong);
  width: 440px;
  max-width: 92%;
  max-height: 90vh;
  color: var(--text-secondary);
  box-shadow: 0 24px 48px -8px rgba(0, 0, 0, 0.6);
  overflow: hidden;
  animation: testudo-modal-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  display: flex;
  flex-direction: column;
  position: relative;
}

.testudo-modal::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--danger);
}

.testudo-material-icon {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-style: normal;
  display: inline-block;
  line-height: 1;
  text-transform: none;
  letter-spacing: normal;
  word-wrap: normal;
  white-space: nowrap;
  direction: ltr;
  -webkit-font-smoothing: antialiased;
}

/* ── Header ── */

.testudo-header,
.testudo-modal-header {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 24px 24px 14px;
  gap: 14px;
  flex-shrink: 0;
  position: relative;
}

.testudo-header-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: var(--danger-bg);
  border: 1px solid var(--danger-border);
  color: var(--danger);
}

.testudo-header-icon .testudo-material-icon {
  font-size: 22px;
}

.testudo-header-text {
  text-align: left;
}

.testudo-title {
  font-family: var(--font-sans);
  font-size: 22px;
  font-weight: 600;
  color: var(--text);
  margin: 0 0 6px 0;
  letter-spacing: -0.02em;
  line-height: 1.2;
}

.testudo-subtitle {
  font-size: 13px;
  font-weight: 400;
  color: var(--text-muted);
  margin: 0;
  line-height: 1.55;
  max-width: 360px;
}

.testudo-subtitle strong {
  color: var(--text-secondary);
  font-weight: 600;
}

.testudo-intent-headline {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary);
  line-height: 1.5;
  margin: 0;
}

/* ── Modal Body & Footer ── */

.testudo-modal-body {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 0 24px;
  overflow-y: auto;
  flex-shrink: 1;
}

.testudo-modal-footer {
  padding: 14px 24px 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  flex-shrink: 0;
}

/* ── Alert Box ── */

.testudo-alert,
.testudo-alert-box {
  margin: 0 24px;
  position: relative;
  border-radius: 10px;
  border: 1px solid var(--danger-border);
  background: var(--danger-bg);
  padding: 14px 16px;
}

.testudo-alert-header {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--danger);
}

.testudo-alert-header .testudo-material-icon {
  font-size: 16px;
}

.testudo-alert-title {
  font-family: var(--font-sans);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--danger);
}

.testudo-alert-subtitle {
  font-size: 12px;
  font-weight: 500;
  color: var(--text-muted);
  letter-spacing: 0.02em;
}

.testudo-alert-description {
  color: var(--text-secondary);
  font-size: 13px;
  font-weight: 400;
  line-height: 1.55;
  margin-top: 6px;
}

/* Severity variants */
.testudo-alert.critical,
.testudo-alert-box.critical {
  border-color: var(--danger-border);
  background: var(--danger-bg);
}

.testudo-alert.critical .testudo-alert-header,
.testudo-alert.critical .testudo-alert-title,
.testudo-alert-box.critical .testudo-alert-header,
.testudo-alert-box.critical .testudo-alert-title {
  color: var(--danger);
}

.testudo-alert.high,
.testudo-alert-box.high {
  border-color: var(--danger-border);
  background: var(--danger-bg);
}

.testudo-alert.high .testudo-alert-header,
.testudo-alert.high .testudo-alert-title,
.testudo-alert-box.high .testudo-alert-header,
.testudo-alert-box.high .testudo-alert-title {
  color: var(--danger);
}

.testudo-alert.medium,
.testudo-alert-medium,
.testudo-alert-box.medium {
  border-color: rgba(245, 158, 11, 0.3);
  background: var(--warn-bg);
}

.testudo-alert.medium .testudo-alert-header,
.testudo-alert.medium .testudo-alert-title,
.testudo-alert-medium .testudo-alert-header,
.testudo-alert-medium .testudo-alert-title,
.testudo-alert-box.medium .testudo-alert-header,
.testudo-alert-box.medium .testudo-alert-title {
  color: var(--warn);
}

.testudo-alert.low,
.testudo-alert-box.low {
  border-color: var(--border-strong);
  background: var(--surface-raised);
}

.testudo-alert.low .testudo-alert-header,
.testudo-alert.low .testudo-alert-title,
.testudo-alert-box.low .testudo-alert-header,
.testudo-alert-box.low .testudo-alert-title {
  color: var(--text-muted);
}

/* ── Context & Address Section ── */

.testudo-address-section {
  margin: 0 24px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.testudo-intent-action {
  font-size: 13px;
  font-weight: 400;
  color: var(--text-secondary);
  line-height: 1.55;
  margin-bottom: 4px;
  padding: 0 2px;
}

.testudo-context {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin: 0 24px;
}

.testudo-context-label {
  font-family: var(--font-sans);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--text-dim);
}

.testudo-context-value {
  font-size: 13px;
  font-weight: 400;
  color: var(--text-secondary);
  line-height: 1.5;
}

.testudo-address-box {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--surface-raised);
  border-radius: 10px;
  padding: 12px 14px;
  border: 1px solid var(--border-subtle);
  transition: border-color 0.15s;
}

.testudo-address-box:hover {
  border-color: var(--border-strong);
}

.testudo-address-label {
  font-family: var(--font-sans);
  font-size: 11px;
  font-weight: 500;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.testudo-address-value {
  display: flex;
  align-items: center;
  gap: 8px;
}

.testudo-address-text {
  font-family: var(--font-mono);
  font-size: 13px;
  color: var(--text-secondary);
  letter-spacing: 0.01em;
}

.testudo-copy-btn {
  background: none;
  border: none;
  color: var(--text-dim);
  cursor: pointer;
  padding: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.15s, background 0.15s;
  border-radius: 4px;
}

.testudo-copy-btn:hover {
  color: var(--text-muted);
  background: rgba(255, 255, 255, 0.04);
}

.testudo-copy-btn .testudo-material-icon {
  font-size: 14px;
}

/* ── Threat List ── */

.testudo-threats,
.testudo-threat-list {
  padding: 0 24px;
  margin: 0;
  overflow-y: auto;
  max-height: 220px;
  flex-shrink: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.testudo-threats-title {
  font-family: var(--font-sans);
  font-size: 11px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--text-dim);
  margin-bottom: 4px;
  padding: 0 2px;
}

.testudo-threat-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  background: var(--surface-raised);
  border-radius: 10px;
  padding: 12px 14px;
  border: 1px solid var(--border-subtle);
}

.testudo-threat-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--warn-bg);
  color: var(--warn);
  flex-shrink: 0;
}

.testudo-threat-icon.critical,
.testudo-threat-icon.high {
  background: var(--danger-bg);
  color: var(--danger);
}

.testudo-threat-icon.medium {
  background: var(--warn-bg);
  color: var(--warn);
}

.testudo-threat-icon.low {
  background: var(--surface-raised);
  color: var(--text-muted);
}

.testudo-threat-icon .testudo-material-icon {
  font-size: 18px;
}

.testudo-threat-content {
  display: flex;
  flex-direction: column;
  min-width: 0;
  flex: 1;
  gap: 2px;
}

.testudo-threat-name,
.testudo-threat-title {
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 600;
  color: var(--text);
  line-height: 1.35;
  letter-spacing: -0.005em;
}

.testudo-threat-desc {
  font-size: 12px;
  font-weight: 400;
  color: var(--text-dim);
  line-height: 1.5;
}

/* ── Buttons ── */

.testudo-buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 14px 24px 20px;
  background: var(--surface);
  flex-shrink: 0;
  position: relative;
}

.testudo-buttons::before {
  content: '';
  position: absolute;
  top: 0;
  left: 24px;
  right: 24px;
  height: 1px;
  background: var(--border-subtle);
}

.testudo-btn {
  width: 100%;
  border-radius: 10px;
  padding: 12px 18px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
  border: 1px solid transparent;
}

.testudo-btn-cancel {
  width: 100%;
  background: var(--brand);
  color: var(--brand-ink);
  border: 1px solid var(--brand);
  border-radius: 10px;
  padding: 12px 18px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background 0.15s, border-color 0.15s;
}

.testudo-btn-cancel:hover {
  background: var(--brand-hover);
  border-color: var(--brand-hover);
}

.testudo-btn-cancel:active {
  transform: scale(0.99);
}

.testudo-btn-cancel .testudo-material-icon {
  font-size: 18px;
}

.testudo-secondary-actions {
  display: flex;
  align-items: center;
  justify-content: center;
}

.testudo-btn-link {
  background: none;
  border: none;
  color: var(--text-dim);
  font-size: 13px;
  font-weight: 400;
  cursor: pointer;
  padding: 6px 12px;
  transition: color 0.15s, background 0.15s;
  border-radius: 6px;
}

.testudo-btn-link:hover {
  color: var(--text-muted);
  background: var(--surface-raised);
}

.testudo-btn-danger {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: transparent;
  border: 1px solid var(--danger-border);
  color: var(--danger);
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  padding: 12px 18px;
  border-radius: 10px;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
}

.testudo-btn-danger:hover {
  background: var(--surface-raised);
  border-color: var(--danger);
  color: var(--danger);
}

.testudo-btn-danger .testudo-material-icon {
  font-size: 14px;
  transition: transform 0.15s;
}

.testudo-btn-danger:hover .testudo-material-icon {
  transform: translateX(2px);
}

.testudo-btn-trust {
  background: transparent;
  border: 1px solid var(--border-strong);
  color: var(--text-muted);
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  padding: 10px 14px;
  border-radius: 10px;
  transition: background 0.15s, color 0.15s, border-color 0.15s;
}

.testudo-btn-trust:hover {
  background: var(--surface-raised);
  color: var(--text-secondary);
  border-color: var(--text-muted);
}

/* ── eth_sign Confirmation ── */

.testudo-confirm-section,
.testudo-eth-sign-confirm {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.testudo-confirm-label {
  font-family: var(--font-sans);
  font-size: 11px;
  color: var(--text-dim);
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.testudo-confirm-input,
.testudo-eth-sign-input {
  width: 100%;
  background: var(--surface-raised);
  border: 1px solid var(--danger-border);
  border-radius: 10px;
  padding: 11px 14px;
  font-size: 13px;
  font-family: var(--font-sans);
  color: var(--text);
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s;
  box-sizing: border-box;
}

.testudo-confirm-input:focus,
.testudo-eth-sign-input:focus {
  border-color: var(--danger);
  box-shadow: 0 0 0 2px rgba(220, 38, 38, 0.15);
}

.testudo-confirm-input::placeholder,
.testudo-eth-sign-input::placeholder {
  color: var(--text-dim);
}

.testudo-btn-danger-confirm {
  width: 100%;
  background: transparent;
  color: var(--text-dim);
  border: 1px solid var(--border-subtle);
  border-radius: 10px;
  padding: 12px 18px;
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  letter-spacing: 0;
  cursor: not-allowed;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: background 0.15s, border-color 0.15s, color 0.15s;
}

.testudo-btn-danger-confirm.enabled {
  background: transparent;
  color: var(--danger);
  border-color: var(--danger-border);
  cursor: pointer;
}

.testudo-btn-danger-confirm.enabled:hover {
  background: var(--surface-raised);
  border-color: var(--danger);
}

/* ── Loading ── */

.testudo-loading-state {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.testudo-spin {
  animation: testudo-spin 1.5s linear infinite;
}

.testudo-loading-icon {
  background: var(--surface-raised);
  border-color: var(--border-strong);
  color: var(--text-muted);
}

.testudo-loading-bar-container {
  margin: 12px 24px;
  height: 2px;
  border-radius: 1px;
  background: var(--border-subtle);
  overflow: hidden;
}

.testudo-loading-bar {
  height: 100%;
  width: 50%;
  border-radius: 1px;
  background: linear-gradient(90deg, transparent, var(--brand), transparent);
  animation: testudo-loading-slide 1.4s ease-in-out infinite;
}

/* ── Toasts (shared) ── */

.testudo-toast,
.testudo-toast-info,
.testudo-toast-unknown {
  position: fixed;
  bottom: 16px;
  right: 16px;
  background: var(--surface);
  border-radius: 12px;
  padding: 14px 16px;
  color: var(--text-secondary);
  font-family: var(--font-sans);
  z-index: 999998;
  max-width: 360px;
  box-shadow: 0 12px 32px -4px rgba(0, 0, 0, 0.6);
  animation: testudo-slide-in 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  display: flex;
  gap: 10px;
  align-items: flex-start;
  -webkit-font-smoothing: antialiased;
  border: 1px solid var(--border-strong);
}

.testudo-toast-icon,
.testudo-toast-unknown-icon {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-size: 20px;
  flex-shrink: 0;
  margin-top: 1px;
}

.testudo-toast-content,
.testudo-toast-unknown-content {
  flex: 1;
}

.testudo-toast-title,
.testudo-toast-unknown-title {
  font-weight: 600;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 5px;
  letter-spacing: -0.005em;
}

.testudo-toast-text,
.testudo-toast-unknown-text {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 4px;
  line-height: 1.55;
}

.testudo-toast-dismiss,
.testudo-toast-unknown-dismiss {
  background: none;
  border: none;
  color: var(--text-dim);
  cursor: pointer;
  font-size: 11px;
  margin-top: 6px;
  padding: 4px 8px;
  border-radius: 6px;
  transition: background 0.15s, color 0.15s;
  font-weight: 500;
}

.testudo-toast-dismiss:hover,
.testudo-toast-unknown-dismiss:hover {
  background: var(--surface-raised);
  color: var(--text-secondary);
}

/* ── Info Toast (specifics) ── */

.testudo-toast,
.testudo-toast-info {
  border: 1px solid rgba(245, 158, 11, 0.3);
}

.testudo-toast .testudo-toast-icon,
.testudo-toast-info .testudo-toast-icon {
  color: var(--warn);
}

.testudo-toast .testudo-toast-title,
.testudo-toast-info .testudo-toast-title {
  color: var(--warn);
}

.testudo-toast-title .testudo-toast-icon-inline {
  font-family: 'Material Symbols Outlined';
  font-variation-settings: 'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24;
  font-size: 14px;
}

/* ── Unknown Toast (specifics) ── */

.testudo-toast-unknown {
  border: 1px solid var(--border-strong);
}

.testudo-toast-unknown-icon {
  color: var(--text-dim);
}

.testudo-toast-unknown-title {
  color: var(--text-muted);
}

.testudo-toast-unknown-address {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--text-dim);
  margin-top: 5px;
}

/* ── Focus States (keyboard navigation) ── */

.testudo-btn:focus-visible,
.testudo-btn-cancel:focus-visible,
.testudo-btn-danger:focus-visible,
.testudo-btn-danger-confirm:focus-visible,
.testudo-btn-trust:focus-visible {
  outline: 2px solid var(--brand);
  outline-offset: 2px;
}

.testudo-btn-link:focus-visible,
.testudo-copy-btn:focus-visible,
.testudo-toast-dismiss:focus-visible,
.testudo-toast-unknown-dismiss:focus-visible {
  outline: 2px solid var(--brand);
  outline-offset: 1px;
  border-radius: 4px;
}

.testudo-confirm-input:focus-visible,
.testudo-eth-sign-input:focus-visible {
  outline: none;
  border-color: var(--danger);
  box-shadow: 0 0 0 2px rgba(220, 38, 38, 0.15);
}

/* ── Utility Classes ── */

.testudo-text-danger {
  color: var(--danger);
}

/* ── Reduced Motion ── */

@media (prefers-reduced-motion: reduce) {
  #testudo-warning-overlay,
  #testudo-warning-overlay *,
  #testudo-warning-overlay *::before,
  #testudo-warning-overlay *::after,
  .testudo-toast,
  .testudo-toast-info,
  .testudo-toast-unknown {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
`;function Tn(e=document.head){if(e.querySelector(`#testudo-warning-styles`))return;let t=document.createElement(`style`);t.id=`testudo-warning-styles`,t.textContent=wn,e.appendChild(t)}const En=BigInt(Xt),Dn=BigInt(Zt),On=BigInt(10)**BigInt(28);function kn(e){try{return BigInt(e)>=Dn}catch{return!1}}function An(e,t,n){try{let r=BigInt(e);if(r>=On||r===En||r===Dn)return n?`Unlimited ${n}`:`Unlimited`;if(t!==null&&t>0){let e=BigInt(10)**BigInt(t),i=r/e,a=r%e;if(a===0n)return jn(i.toLocaleString(`en-US`),n);let o=a.toString().padStart(t,`0`),s=o.replace(/0+$/,``),c=s.length>6?s.slice(0,6):s;return jn(`${i.toLocaleString(`en-US`)}.${c}`,n)}return jn(r.toLocaleString(`en-US`),n)}catch{return n?`? ${n}`:e}}function jn(e,t){return t?`${e} ${t}`:e}function Mn(e){if(kn(e))return`Never`;try{let t=Number(e);if(Number.isNaN(t)||t<=0)return e;let n=new Date(t*1e3),r=Date.now(),i=n.getTime()-r,a=n.toLocaleString(`en-US`,{month:`short`,day:`numeric`,year:`numeric`,hour:`2-digit`,minute:`2-digit`});if(i<0)return`${a} (expired)`;let o=Math.floor(i/6e4);if(o<60)return`${a} (in ${o}m)`;let s=Math.floor(o/60);if(s<24)return`${a} (in ${s}h)`;let c=Math.floor(s/24);return`${a} (in ${c}d)`}catch{return e}}const Nn={0:`All Networks (Replay Risk)`,1:`Ethereum`,10:`Optimism`,56:`BNB Chain`,100:`Gnosis`,137:`Polygon`,250:`Fantom`,324:`zkSync Era`,420:`Optimism Goerli`,8453:`Base`,42161:`Arbitrum One`,42170:`Arbitrum Nova`,43114:`Avalanche`,59144:`Linea`,534352:`Scroll`,7777777:`Zora`,11155111:`Sepolia`};function Pn(e){if(e==null)return;let t=typeof e==`string`?Number(e):e;return Nn[t]}function Fn(e,t){let n=K(e.spender),r=q(e.value),i=t?.symbol??e.tokenName??null,a=t?.decimals??null,o;o=e.value===`batch`?`Multiple tokens (batch)`:r?i?`Unlimited ${i}`:`Unlimited`:e.value&&a!==null?An(e.value,a,i):e.value?i?`${e.value} (raw) ${i}`:e.value:`Unknown amount`;let s=[{label:`Spender`,value:n,emphasis:`danger`,mono:!0},{label:`Amount`,value:o,emphasis:r?`danger`:`warning`}];if(e.token&&s.push({label:`Token Contract`,value:K(e.token),mono:!0}),e.deadline){let t=Mn(e.deadline);s.push({label:`Expires`,value:t,emphasis:kn(e.deadline)?`danger`:`info`})}let c=r?`Unlimited ${i??`Token`} Permit`:`${i??`Token`} Permit Request`;return{headline:c,action:`Allow ${n} to spend ${o}`,details:s}}function In(e,t){let n=K(e.spender),r=q(e.amount),i=t?.symbol??null,a=t?.decimals??null,o=r?i?`Unlimited ${i}`:`Unlimited`:An(e.amount,a,i),s=[{label:`Spender`,value:n,emphasis:`danger`,mono:!0},{label:`Amount`,value:o,emphasis:r?`danger`:`warning`},{label:`Token Contract`,value:K(e.tokenAddress),mono:!0},{label:`Operation`,value:e.type===`approve`?`approve()`:e.type===`increaseAllowance`?`increaseAllowance()`:`decreaseAllowance()`,emphasis:`info`}],c=r?`Unlimited ${i??`Token`} Approval`:`${i??`Token`} Approval Request`;return{headline:c,action:`Allow ${n} to spend ${o}`,details:s}}function Ln(e){let t=K(e.operator),n=e.collectionName??K(e.collectionAddress),r=[{label:`Operator`,value:t,emphasis:`danger`,mono:!0},{label:`Collection`,value:n},{label:`Access Level`,value:`Full Collection`,emphasis:`danger`}];return{headline:`NFT Collection Approval`,action:`Grant ${t} full access to your ${n}`,details:r}}function Rn(e,t,n){let r=K(e),i=Pn(t),a=[{label:`Delegate`,value:r,emphasis:`danger`,mono:!0}];return i&&a.push({label:`Network`,value:i}),n&&n.risk!==`LOW`&&(a.push({label:`Deployer Activity`,value:`${n.deployerNonce} transactions`,emphasis:n.risk===`CRITICAL`?`danger`:`warning`}),a.push({label:`Contract Age`,value:zn(n.contractAge),emphasis:n.contractAge<86400?`danger`:`info`})),{headline:`Wallet Delegation Request`,action:`Delegate wallet control to ${r}${i?` on ${i}`:``}`,details:a,chainName:i}}function zn(e){return e<3600?`${Math.floor(e/60)} minutes`:e<86400?`${Math.floor(e/3600)} hours`:`${Math.floor(e/86400)} days`}function Bn(e){let t=K(e);return{headline:`Suspicious Transaction`,action:`Send funds to ${t}`,details:[{label:`Recipient`,value:t,emphasis:`danger`,mono:!0}]}}function Vn(e,t){let n=[{label:`Method`,value:e.type,emphasis:`warning`},{label:`Message${e.isHex?` (hex)`:``}`,value:e.messagePreview,mono:!0}],r=t===`HIGH`;return{headline:r?`Suspicious Message Detected`:`Blind Signature Request`,action:r?`Phishing patterns found in ${e.type} message`:`Sign arbitrary data with ${e.type}`,details:n}}function Hn(e){let t=[{label:`Primary Type`,value:e.primaryType}];e.domainName&&t.push({label:`Domain`,value:e.domainName});for(let n of e.maliciousAddresses.slice(0,3))t.push({label:`Found in: ${n.fieldPath}`,value:K(n.address),emphasis:`danger`,mono:!0});return{headline:`Malicious Address in Signed Data`,action:`Known malicious address found in ${e.primaryType}`,details:t}}function Un(e){let t=K(e);return{headline:`Cross-Chain Replay Risk`,action:`Delegate wallet control to ${t} on ALL networks`,details:[{label:`Delegate`,value:t,emphasis:`danger`,mono:!0},{label:`Network`,value:`All Networks (chainId=0)`,emphasis:`danger`},{label:`Impact`,value:`Signature can be replayed on every EVM chain`,emphasis:`danger`}]}}function Wn(e){return{headline:`Dangerous: eth_sign Detected`,action:`Sign raw hash via deprecated eth_sign`,details:[{label:`Method`,value:`eth_sign (deprecated)`,emphasis:`danger`},{label:`Message`,value:e.messagePreview,mono:!0}]}}function Gn(e,t){let n=e.context??`delegation`;switch(n){case`permit`:return e.permitInfo?Fn(e.permitInfo,t):null;case`approval`:return e.approvalInfo?In(e.approvalInfo,t):null;case`nft-approval`:return e.nftApprovalInfo?Ln(e.nftApprovalInfo):null;case`delegation`:return Rn(e.analysis.address,e.chainId,e.analysis.deployerRisk);case`replay-risk`:return Un(e.analysis.address);case`transaction`:return Bn(e.analysis.address);case`blind-signature`:return e.blindSignatureInfo?Vn(e.blindSignatureInfo,e.analysis.risk):null;case`typed-data-scan`:return e.typedDataScanInfo?Hn(e.typedDataScanInfo):null;case`eth-sign-danger`:return e.blindSignatureInfo?Wn(e.blindSignatureInfo):null;default:return null}}const Kn=500,qn={"0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48":{symbol:`USDC`,decimals:6,name:`USD Coin`,isVerified:!0},"0xdac17f958d2ee523a2206206994597c13d831ec7":{symbol:`USDT`,decimals:6,name:`Tether USD`,isVerified:!0},"0x6b175474e89094c44da98b954eedeac495271d0f":{symbol:`DAI`,decimals:18,name:`Dai Stablecoin`,isVerified:!0},"0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2":{symbol:`WETH`,decimals:18,name:`Wrapped Ether`,isVerified:!0},"0x2260fac5e5542a773aa44fbcfedf7c193bc2c599":{symbol:`WBTC`,decimals:8,name:`Wrapped BTC`,isVerified:!0},"0x514910771af9ca656af840dff83e8264ecf986ca":{symbol:`LINK`,decimals:18,name:`ChainLink Token`,isVerified:!0},"0x1f9840a85d5af5bf1d1762f925bdaddc4201f984":{symbol:`UNI`,decimals:18,name:`Uniswap`,isVerified:!0},"0x7fc66500c84a76ad7e9c93437bfc5ac33e2ddae9":{symbol:`AAVE`,decimals:18,name:`Aave Token`,isVerified:!0},"0x9f8f72aa9304c8b593d555f12ef6589cc3a579a2":{symbol:`MKR`,decimals:18,name:`Maker`,isVerified:!0},"0xae7ab96520de3a18e5e111b5eaab095312d7fe84":{symbol:`stETH`,decimals:18,name:`Liquid staked Ether 2.0`,isVerified:!0},"0xbe9895146f7af43049ca1c1ae358b0541ea49704":{symbol:`cbETH`,decimals:18,name:`Coinbase Wrapped Staked ETH`,isVerified:!0},"0x853d955acef822db058eb8505911ed77f175b99e":{symbol:`FRAX`,decimals:18,name:`Frax`,isVerified:!0},"0x4fabb145d64652a948d72533023f6e7a623c7c53":{symbol:`BUSD`,decimals:18,name:`Binance USD`,isVerified:!0},"0x95ad61b0a150d79219dcf64e1e6cc01f0b64c4ce":{symbol:`SHIB`,decimals:18,name:`SHIBA INU`,isVerified:!0}},Jn=new Map;function Yn(e){let t=e.toLowerCase(),n=Jn.get(t);if(n)return n;let r=qn[t];if(r){let e={address:t,...r};return Jn.set(t,e),e}return null}async function Xn(e){let t=Yn(e);if(t)return t;let n=e.toLowerCase(),r=await _t(n),i={address:n,name:r.name,symbol:r.symbol,decimals:r.decimals,isVerified:!1};return Zn(n,i),i}function Zn(e,t){Jn.size>=Kn&&Jn.clear(),Jn.set(e,t)}function Qn(e){return e===`personal_sign`}function $n(e,t){if(!Array.isArray(t)||t.length<2)return null;let[n,r]=t,i=e===`personal_sign`?String(n):String(r),a=e===`personal_sign`?String(r):String(n);if(!/^0x[a-fA-F0-9]{40}$/.test(a))return null;let o=/^0x[a-fA-F0-9]+$/.test(i),s=i;if(o&&i.length>2)try{let e=i.slice(2,4002),t=e.match(/.{1,2}/g);if(t){let e=t.map(e=>String.fromCharCode(parseInt(e,16))).join(``);/^[\x20-\x7E\s]+$/.test(e)&&(s=e)}}catch{}let c=s;return c.length>100&&(c=`${c.slice(0,97)}...`),{type:e,message:i,decodedMessage:s,messagePreview:c,signer:a.toLowerCase(),isHex:o}}const er=[{category:`airdrop_scam`,regex:/claim\s+(your\s+)?airdrop/i,score:3},{category:`airdrop_scam`,regex:/free\s+tokens?/i,score:3},{category:`airdrop_scam`,regex:/claim\s+(your\s+)?reward/i,score:3},{category:`verification_scam`,regex:/verify\s+(your\s+)?wallet/i,score:3},{category:`verification_scam`,regex:/confirm\s+(your\s+)?ownership/i,score:3},{category:`verification_scam`,regex:/security\s+(check|verification)/i,score:3},{category:`urgency`,regex:/expires?\s+in/i,score:2},{category:`urgency`,regex:/act\s+now/i,score:2},{category:`urgency`,regex:/limited\s+time/i,score:2},{category:`urgency`,regex:/within\s+\d+\s+(hour|minute)/i,score:2},{category:`impersonation`,regex:/opensea/i,score:2},{category:`impersonation`,regex:/metamask/i,score:2},{category:`impersonation`,regex:/uniswap/i,score:2},{category:`impersonation`,regex:/coinbase/i,score:2},{category:`financial_lure`,regex:/you\s+(have\s+)?won/i,score:2},{category:`financial_lure`,regex:/prize/i,score:2},{category:`financial_lure`,regex:/bonus\s+token/i,score:2}];function tr(e){let t=0,n=new Set;for(let r of er)r.regex.test(e)&&(t+=r.score,n.add(r.category));let r=Array.from(n),i=t>=3?`HIGH`:t>=1?`MEDIUM`:`INFO`;return{score:t,patterns:r,risk:i}}function nr(e){return!(!e.types?.Authorization||e.primaryType!==`Authorization`||!e.message?.address)}function rr(e){let t=e.primaryType;return t===`Permit`||t===`PermitSingle`||t===`PermitBatch`||t===`PermitTransferFrom`||t===`PermitWitnessTransferFrom`}function Y(e){return typeof e!=`string`||!/^0x[a-fA-F0-9]{40}$/.test(e)?null:e.toLowerCase()}function ir(e){let t=[],n=new Set,r=10,i=100,a=Y(e.domain?.verifyingContract);a&&(n.add(a),t.push({address:a,fieldPath:`domain.verifyingContract`}));let o=e.types;function s(e,a,c,l){if(l>r||t.length>=i||a===`EIP712Domain`)return;let u=o[a];if(!(!Array.isArray(u)||typeof e!=`object`||!e))for(let r of u){let a=e[r.name],u=c?`${c}.${r.name}`:r.name;if(r.type===`address`){let e=Y(a);e&&!n.has(e)&&(n.add(e),t.push({address:e,fieldPath:u}))}else if(r.type===`address[]`&&Array.isArray(a))for(let e=0;e<a.length&&t.length<i;e++){let r=Y(a[e]);r&&!n.has(r)&&(n.add(r),t.push({address:r,fieldPath:`${u}[${e}]`}))}else if(r.type.endsWith(`[]`)){let e=r.type.slice(0,-2);if(o[e]&&Array.isArray(a))for(let n=0;n<a.length&&t.length<i;n++)s(a[n],e,`${u}[${n}]`,l+1)}else o[r.type]&&s(a,r.type,u,l+1)}}return s(e.message,e.primaryType,`message`,0),t}function ar(e){let t=e.types[e.primaryType];return Array.isArray(t)?t.some(e=>e.name===`holder`)&&t.some(e=>e.name===`allowed`):!1}function or(e){let{primaryType:t,message:n,domain:r}=e;if(t===`Permit`){let t=Y(n.spender);if(!t)return null;let i=ar(e);return{type:i?`dai-permit`:`permit`,spender:t,value:i?n.allowed===!0?`unlimited`:`0`:String(n.value??``),deadline:n.deadline==null?n.expiry==null?void 0:String(n.expiry):String(n.deadline),token:r?.verifyingContract,tokenName:r?.name}}if(t===`PermitSingle`){let e=Y(n.spender);if(!e)return null;let t=n.details;return{type:`permit2-single`,spender:e,value:t?.amount==null?void 0:String(t.amount),deadline:n.sigDeadline==null?void 0:String(n.sigDeadline),token:typeof t?.token==`string`?t.token:void 0}}if(t===`PermitBatch`){let e=Y(n.spender);if(!e)return null;let t=n.details;if(!Array.isArray(t)||t.length===0)return null;let r=t.some(e=>q(e.amount==null?void 0:String(e.amount)));return{type:`permit2-batch`,spender:e,deadline:n.sigDeadline==null?void 0:String(n.sigDeadline),token:typeof t[0]?.token==`string`?t[0].token:void 0,value:r?`unlimited`:`batch`}}if(t===`PermitTransferFrom`||t===`PermitWitnessTransferFrom`){let e=Y(n.spender);if(!e)return null;let r=n.permitted;return{type:t===`PermitTransferFrom`?`permit2-transfer`:`permit2-witness-transfer`,spender:e,value:r?.amount==null?void 0:String(r.amount),deadline:n.deadline==null?void 0:String(n.deadline),token:typeof r?.token==`string`?r.token:void 0}}return null}window.__TESTUDO_LOADED__=!0;let X=null,sr=null;function cr(e){let t=document.getElementById(`testudo-fonts`);if(t?.textContent){let n=document.createElement(`style`);n.textContent=t.textContent,e.appendChild(n)}let n=document.createElement(`div`);e.appendChild(n),de(G(x,{children:[G(Cn,{}),G(Ht,{}),G(Ut,{})]}),n)}function lr(){if(X?.isConnected&&sr)return;let e=document.body||document.documentElement;if(X&&!X.isConnected){e.appendChild(X);return}X=document.createElement(`div`),X.id=`testudo-root`,X.style.cssText=`display:block!important;position:static!important;visibility:visible!important;`,e.appendChild(X),sr=X.attachShadow({mode:`open`}),Tn(sr),cr(sr)}async function Z(e,t){let n=t?Yn(t):null,r=Gn(e,n);if(lr(),t&&!n){let n=Ct({...e,intent:r??void 0}),i=St();return Xn(t).then(t=>{let n=Gn(e,t);n&&Et(n,i)}).catch(e=>{console.debug(`[Testudo] Background token resolution failed:`,e)}),n}return Ct({...e,intent:r??void 0})}function ur(e){lr(),Pt(e)}function dr(e){lr(),Lt(e)}let fr=!1,Q=null,pr,mr=null;function hr(e){if(typeof e==`number`&&Number.isFinite(e)&&e>0)return e;if(!(typeof e!=`string`||e.length===0))try{let t=Number.parseInt(e,16);return Number.isFinite(t)&&t>0?t:void 0}catch{return}}async function $(e){return pr===void 0?mr||(mr=(async()=>{try{let t=await e({method:`eth_chainId`}),n=hr(t);return n!==void 0&&(pr=n),n}catch{return}finally{mr=null}})(),mr):pr}function gr(e){if(typeof e?.on==`function`)try{e.on(`chainChanged`,e=>{pr=hr(e)})}catch{}}function _r(){if(fr||window.ethereum===void 0)return;console.log(`[Testudo] 🛡️ Initializing EIP-7702 protection...`),fr=!0;let e=window.ethereum.request.bind(window.ethereum);gr(window.ethereum);try{let t=async t=>{if(t.method===`eth_sendTransaction`)try{let n=t.params?.[0],r=n?.to,i=n?.data;if(r&&i&&nn(i)){let n=rn(i,r);if(n){if(console.log(`[Testudo] NFT setApprovalForAll detected`),!n.approved)return console.log(`[Testudo] NFT approval revocation detected, passing through`),e(t);let r=await $(e),i=await pt(n.operator,r);if(i.risk===`CRITICAL`||i.risk===`HIGH`){let r=await Z({analysis:i,context:`nft-approval`,nftApprovalInfo:n});if(!r)throw Error(`Testudo: NFT approval blocked by user - malicious operator detected`);return e(t)}if(i.whitelisted)return console.log(`[Testudo] Operator is whitelisted, passing through`),e(t);let a=an(n.operator);if(a)return console.log(`[Testudo] Known marketplace: ${a}`),e(t);let o={...i,risk:`HIGH`,threats:[`nft_full_collection_access`,...i.threats],blocked:!0},s=await Z({analysis:o,context:`nft-approval`,nftApprovalInfo:n});if(!s)throw Error(`Testudo: NFT approval blocked by user - unknown operator`);return e(t)}}if(r&&i&&Qt(i)){let n=$t(i,r);if(n){if(console.log(`[Testudo] Token approval detected:`,n.type),tn(n.amount))return console.log(`[Testudo] Approval revocation detected, passing through`),e(t);let r=await $(e),i=await pt(n.spender,r),a=q(n.amount);if(i.risk===`CRITICAL`||i.risk===`HIGH`){let e=await Z({analysis:i,context:`approval`,approvalInfo:n},n.tokenAddress);if(!e)throw Error(`Testudo: Approval blocked by user - malicious spender detected`)}else if(a){let e={...i,risk:`HIGH`,threats:[`unlimited_approval`,...i.threats],blocked:!0},t=await Z({analysis:e,context:`approval`,approvalInfo:n},n.tokenAddress);if(!t)throw Error(`Testudo: Approval blocked by user - unlimited amount`)}return e(t)}}if(r&&/^0x[a-fA-F0-9]{40}$/.test(r)){let t=await $(e),n=await pt(r,t);if(n.risk===`CRITICAL`||n.risk===`HIGH`){let e=await Z({analysis:n,context:`transaction`});if(!e)throw Error(`Testudo: Transaction blocked by user - malicious recipient detected`)}}return e(t)}catch(n){if(n instanceof Error&&n.message.includes(`Testudo`))throw n;return console.error(`[Testudo] Error checking transaction:`,n),e(t)}if(t.method===`eth_sign`){let n=$n(`eth_sign`,t.params);if(!n)throw console.warn(`[Testudo] eth_sign blocked — malformed parameters`),Error(`Testudo: eth_sign blocked — malformed parameters`);console.log(`[Testudo] eth_sign detected — CRITICAL: deprecated method signs raw hashes`);let r={address:n.signer,risk:`CRITICAL`,threats:[`eth_sign_deprecated`,`blind_signature`],warnings:[{type:`ETH_SIGN_DEPRECATED`,title:`Deprecated: eth_sign`,description:`eth_sign signs a raw 32-byte hash without any safety prefix. An attacker can craft a valid transaction hash, and signing it gives them full control to execute that transaction from your wallet.`,severity:`CRITICAL`}],blocked:!0,whitelisted:!1},i=await Z({analysis:r,context:`eth-sign-danger`,blindSignatureInfo:n});if(!i)throw Error(`Testudo: eth_sign blocked by user — deprecated method rejected`);return e(t)}if(Qn(t.method)){let n=$n(t.method,t.params);if(n){console.log(`[Testudo] Blind signature detected: ${n.type}`);let e=tr(n.decodedMessage),t=e.risk===`HIGH`,r=t?[...e.patterns,`blind_signature`]:[`blind_signature`],i={address:n.signer,risk:t?`HIGH`:`MEDIUM`,threats:r,warnings:[{type:t?`PHISHING_PATTERN`:`BLIND_SIGNATURE`,title:t?`Suspicious Message Detected`:`Blind Signature Request`,description:t?`This message contains patterns commonly used in phishing attacks.`:`You are signing data that cannot be verified. This could authorize actions you cannot see.`,severity:t?`HIGH`:`MEDIUM`}],blocked:t,whitelisted:!1},a=await Z({analysis:i,context:`blind-signature`,blindSignatureInfo:n});if(!a)throw Error(`Testudo: ${n.type} blocked by user - blind signature rejected`)}return e(t)}if(t.method!==`eth_signTypedData_v4`&&t.method!==`eth_signTypedData_v3`)return e(t);try{let n=t.params,r=n[1],i=typeof r==`string`?JSON.parse(r):r;if(rr(i)){let n=or(i);if(n){console.log(`[Testudo] Permit signature detected:`,n.type);let r=hr(i.domain?.chainId)??await $(e),a=await pt(n.spender,r),o=q(n.value);if(a.risk===`CRITICAL`||a.risk===`HIGH`){let e=await Z({analysis:a,context:`permit`,permitInfo:n},n.token);if(!e)throw Error(`Testudo: Permit blocked by user - malicious spender detected`)}else if(o){let e={...a,risk:`HIGH`,threats:[`unlimited_approval`,...a.threats],blocked:!0},t=await Z({analysis:e,context:`permit`,permitInfo:n},n.token);if(!t)throw Error(`Testudo: Permit blocked by user - unlimited approval`)}return e(t)}}if(!nr(i)){try{let t=ir(i);if(t.length>0){let n=hr(i.domain?.chainId)??await $(e),{malicious:r,results:a}=await mt(t,n);if(r.length>0){let e=r[0].address.toLowerCase(),t=a.get(e),n={address:e,risk:`CRITICAL`,threats:[`typed_data_malicious_address`,...t?.threats||[]],warnings:[{type:`TYPED_DATA_MALICIOUS_ADDRESS`,title:`Malicious Address in Signed Data`,description:`A known malicious address was found in the data you are about to sign.`,severity:`CRITICAL`}],blocked:!0,whitelisted:!1},o={maliciousAddresses:r,primaryType:i.primaryType,domainName:i.domain?.name},s=await Z({analysis:n,context:`typed-data-scan`,typedDataScanInfo:o});if(!s)throw Error(`Testudo: Typed data blocked by user - malicious address in signed data`)}}}catch(e){if(e instanceof Error&&e.message.includes(`Testudo`))throw e;console.error(`[Testudo] Error scanning typed data:`,e)}return e(t)}console.log(`[Testudo] EIP-7702 authorization detected!`);let a=i.message.address,o=i.message.chainId,s=o===0||o===`0`||o===`0x0`||o===`0x00`;lr();let c=wt({context:`delegation`,address:a}),l;try{let t=hr(o),n=t??await $(e);l=await ht(a,n)}catch(n){return console.error(`[Testudo] Analysis failed, failing open:`,n),Dt(),e(t)}if(s){let e={type:`EIP7702_REPLAY_RISK`,severity:`CRITICAL`,title:`Cross-Chain Replay Risk`,description:`This authorization uses chainId=0, making it valid on every EVM network. An attacker can replay your signature on any chain to drain funds across all networks.`};l={...l,risk:`CRITICAL`,blocked:!0,threats:[`eip7702_replay_risk`,...l.threats??[]],warnings:[e,...l.warnings??[]]}}if(l.risk===`CRITICAL`||l.risk===`HIGH`){let e=s?`replay-risk`:`delegation`,t=Gn({analysis:l,context:e,chainId:o},null);Tt(l,t??void 0,e);let n=await c;if(!n)throw Error(s?`Testudo: Delegation blocked by user — cross-chain replay risk rejected`:`Testudo: Delegation blocked by user - dangerous contract detected`)}else l.risk===`MEDIUM`?(Dt(),ur(l)):(Dt(),l.risk===`UNKNOWN`&&dr(l));return e(t)}catch(n){if(n instanceof Error&&n.message.includes(`Testudo`))throw n;return console.error(`[Testudo] Error analyzing request:`,n),e(t)}},n=Object.getOwnPropertyDescriptor(window.ethereum,`request`);n&&n.configurable===!1?n.value===t?Q=t:(console.warn(`[Testudo] .request already locked by another party`),Q=null,fr=!1):(Object.defineProperty(window.ethereum,`request`,{value:t,writable:!1,configurable:!1,enumerable:!0}),Q=t)}catch(e){console.error(`[Testudo] Failed to wrap provider (frozen object?):`,e),fr=!1,Q=null;return}console.log(`[Testudo] ✅ Protection active`)}let vr;window.ethereum!==void 0&&(vr=window.ethereum),_r();let yr=window.ethereum;Object.defineProperty(window,`ethereum`,{configurable:!0,enumerable:!0,get(){return yr},set(e){e!==yr&&e!==vr?(yr=e,fr=!1,Q=null,vr=e,_r()):yr=e}}),setInterval(()=>{if(window.ethereum!==void 0&&Q){let e=window.ethereum.request;e!==Q&&(console.warn(`[Testudo] Provider wrapper tampered — re-wrapping`),fr=!1,_r())}},2e3);